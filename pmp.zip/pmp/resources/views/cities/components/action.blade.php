<div class="btn-group">
    <a href="{{ route('cities.edit',$row->id) }}" class="btn btn-sm btn-outline-warning"><i class="bi bi-pencil-fill"></i></a>
</div>