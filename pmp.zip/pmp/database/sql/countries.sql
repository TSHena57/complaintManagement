-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 22, 2025 at 12:47 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mututal_asses`
--

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `iso3` char(3) DEFAULT NULL,
  `numeric_code` char(3) DEFAULT NULL,
  `iso2` char(2) DEFAULT NULL,
  `phonecode` varchar(255) DEFAULT NULL,
  `capital` varchar(255) DEFAULT NULL,
  `currency` varchar(255) DEFAULT NULL,
  `currency_name` varchar(255) DEFAULT NULL,
  `currency_symbol` varchar(255) DEFAULT NULL,
  `tld` varchar(255) DEFAULT NULL,
  `native` varchar(255) DEFAULT NULL,
  `region` varchar(255) DEFAULT NULL,
  `region_id` mediumint(8) UNSIGNED DEFAULT NULL,
  `subregion` varchar(255) DEFAULT NULL,
  `subregion_id` mediumint(8) UNSIGNED DEFAULT NULL,
  `nationality` varchar(255) DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `flag` tinyint(1) NOT NULL DEFAULT 1,
  `wikiDataId` varchar(255) DEFAULT NULL COMMENT 'Rapid API GeoDB Cities'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `name`, `iso3`, `numeric_code`, `iso2`, `phonecode`, `capital`, `currency`, `currency_name`, `currency_symbol`, `tld`, `native`, `region`, `region_id`, `subregion`, `subregion_id`, `nationality`, `latitude`, `longitude`, `created_at`, `updated_at`, `flag`, `wikiDataId`) VALUES
(1, 'Afghanistan', 'AFG', '004', 'AF', '93', 'Kabul', 'AFN', 'Afghan afghani', '؋', '.af', 'افغانستان', 'Asia', 3, 'Southern Asia', 14, 'Afghan', 33.00000000, 65.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q889'),
(2, 'Aland Islands', 'ALA', '248', 'AX', '358', 'Mariehamn', 'EUR', 'Euro', '€', '.ax', 'Åland', 'Europe', 4, 'Northern Europe', 18, 'Aland Island', 60.11666700, 19.90000000, '2018-07-21 12:41:03', '2024-12-19 20:22:33', 1, 'Q5689'),
(3, 'Albania', 'ALB', '008', 'AL', '355', 'Tirana', 'ALL', 'Albanian lek', 'Lek', '.al', 'Shqipëria', 'Europe', 4, 'Southern Europe', 16, 'Albanian ', 41.00000000, 20.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q222'),
(4, 'Algeria', 'DZA', '012', 'DZ', '213', 'Algiers', 'DZD', 'Algerian dinar', 'دج', '.dz', 'الجزائر', 'Africa', 1, 'Northern Africa', 1, 'Algerian', 28.00000000, 3.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q262'),
(5, 'American Samoa', 'ASM', '016', 'AS', '1', 'Pago Pago', 'USD', 'United States dollar', '$', '.as', 'American Samoa', 'Oceania', 5, 'Polynesia', 22, 'American Samoan', -14.33333333, -170.00000000, '2018-07-21 12:41:03', '2024-12-23 15:33:12', 1, 'Q16641'),
(6, 'Andorra', 'AND', '020', 'AD', '376', 'Andorra la Vella', 'EUR', 'Euro', '€', '.ad', 'Andorra', 'Europe', 4, 'Southern Europe', 16, 'Andorran', 42.50000000, 1.50000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q228'),
(7, 'Angola', 'AGO', '024', 'AO', '244', 'Luanda', 'AOA', 'Angolan kwanza', 'Kz', '.ao', 'Angola', 'Africa', 1, 'Middle Africa', 2, 'Angolan', -12.50000000, 18.50000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q916'),
(8, 'Anguilla', 'AIA', '660', 'AI', '1', 'The Valley', 'XCD', 'Eastern Caribbean dollar', '$', '.ai', 'Anguilla', 'Americas', 2, 'Caribbean', 7, 'Anguillan', 18.25000000, -63.16666666, '2018-07-21 12:41:03', '2024-12-23 15:33:12', 1, 'Q25228'),
(9, 'Antarctica', 'ATA', '010', 'AQ', '672', '', 'AAD', 'Antarctican dollar', '$', '.aq', 'Antarctica', 'Polar', 6, '', NULL, 'Antarctic', -74.65000000, 4.48000000, '2018-07-21 12:41:03', '2024-12-19 20:27:53', 1, 'Q51'),
(10, 'Antigua and Barbuda', 'ATG', '028', 'AG', '1', 'St. John\'s', 'XCD', 'Eastern Caribbean dollar', '$', '.ag', 'Antigua and Barbuda', 'Americas', 2, 'Caribbean', 7, 'Antiguan or Barbudan', 17.05000000, -61.80000000, '2018-07-21 12:41:03', '2024-09-05 16:47:03', 1, 'Q781'),
(11, 'Argentina', 'ARG', '032', 'AR', '54', 'Buenos Aires', 'ARS', 'Argentine peso', '$', '.ar', 'Argentina', 'Americas', 2, 'South America', 8, 'Argentine', -34.00000000, -64.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q414'),
(12, 'Armenia', 'ARM', '051', 'AM', '374', 'Yerevan', 'AMD', 'Armenian dram', '֏', '.am', 'Հայաստան', 'Asia', 3, 'Western Asia', 11, 'Armenian', 40.00000000, 45.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q399'),
(13, 'Aruba', 'ABW', '533', 'AW', '297', 'Oranjestad', 'AWG', 'Aruban florin', 'ƒ', '.aw', 'Aruba', 'Americas', 2, 'Caribbean', 7, 'Aruban', 12.50000000, -69.96666666, '2018-07-21 12:41:03', '2024-12-19 21:03:41', 1, 'Q21203'),
(14, 'Australia', 'AUS', '036', 'AU', '61', 'Canberra', 'AUD', 'Australian dollar', '$', '.au', 'Australia', 'Oceania', 5, 'Australia and New Zealand', 19, 'Australian', -27.00000000, 133.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q408'),
(15, 'Austria', 'AUT', '040', 'AT', '43', 'Vienna', 'EUR', 'Euro', '€', '.at', 'Österreich', 'Europe', 4, 'Western Europe', 17, 'Austrian', 47.33333333, 13.33333333, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q40'),
(16, 'Azerbaijan', 'AZE', '031', 'AZ', '994', 'Baku', 'AZN', 'Azerbaijani manat', 'm', '.az', 'Azərbaycan', 'Asia', 3, 'Western Asia', 11, 'Azerbaijani, Azeri', 40.50000000, 47.50000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q227'),
(17, 'The Bahamas', 'BHS', '044', 'BS', '1', 'Nassau', 'BSD', 'Bahamian dollar', 'B$', '.bs', 'Bahamas', 'Americas', 2, 'Caribbean', 7, 'Bahamian', 24.25000000, -76.00000000, '2018-07-21 12:41:03', '2024-09-05 16:47:03', 1, 'Q778'),
(18, 'Bahrain', 'BHR', '048', 'BH', '973', 'Manama', 'BHD', 'Bahraini dinar', '.د.ب', '.bh', '‏البحرين', 'Asia', 3, 'Western Asia', 11, 'Bahraini', 26.00000000, 50.55000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q398'),
(19, 'Bangladesh', 'BGD', '050', 'BD', '880', 'Dhaka', 'BDT', 'Bangladeshi taka', '৳', '.bd', 'Bangladesh', 'Asia', 3, 'Southern Asia', 14, 'Bangladeshi', 24.00000000, 90.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q902'),
(20, 'Barbados', 'BRB', '052', 'BB', '1', 'Bridgetown', 'BBD', 'Barbadian dollar', 'Bds$', '.bb', 'Barbados', 'Americas', 2, 'Caribbean', 7, 'Barbadian', 13.16666666, -59.53333333, '2018-07-21 12:41:03', '2024-09-05 16:47:03', 1, 'Q244'),
(21, 'Belarus', 'BLR', '112', 'BY', '375', 'Minsk', 'BYN', 'Belarusian ruble', 'Br', '.by', 'Белару́сь', 'Europe', 4, 'Eastern Europe', 15, 'Belarusian', 53.00000000, 28.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q184'),
(22, 'Belgium', 'BEL', '056', 'BE', '32', 'Brussels', 'EUR', 'Euro', '€', '.be', 'België', 'Europe', 4, 'Western Europe', 17, 'Belgian', 50.83333333, 4.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q31'),
(23, 'Belize', 'BLZ', '084', 'BZ', '501', 'Belmopan', 'BZD', 'Belize dollar', '$', '.bz', 'Belize', 'Americas', 2, 'Central America', 9, 'Belizean', 17.25000000, -88.75000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q242'),
(24, 'Benin', 'BEN', '204', 'BJ', '229', 'Porto-Novo', 'XOF', 'West African CFA franc', 'CFA', '.bj', 'Bénin', 'Africa', 1, 'Western Africa', 3, 'Beninese, Beninois', 9.50000000, 2.25000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q962'),
(25, 'Bermuda', 'BMU', '060', 'BM', '1', 'Hamilton', 'BMD', 'Bermudian dollar', '$', '.bm', 'Bermuda', 'Americas', 2, 'Northern America', 6, 'Bermudian, Bermudan', 32.33333333, -64.75000000, '2018-07-21 12:41:03', '2024-12-19 21:04:08', 1, 'Q23635'),
(26, 'Bhutan', 'BTN', '064', 'BT', '975', 'Thimphu', 'BTN', 'Bhutanese ngultrum', 'Nu.', '.bt', 'ʼbrug-yul', 'Asia', 3, 'Southern Asia', 14, 'Bhutanese', 27.50000000, 90.50000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q917'),
(27, 'Bolivia', 'BOL', '068', 'BO', '591', 'Sucre', 'BOB', 'Bolivian boliviano', 'Bs.', '.bo', 'Bolivia', 'Americas', 2, 'South America', 8, 'Bolivian', -17.00000000, -65.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q750'),
(28, 'Bosnia and Herzegovina', 'BIH', '070', 'BA', '387', 'Sarajevo', 'BAM', 'Bosnia and Herzegovina convertible mark', 'KM', '.ba', 'Bosna i Hercegovina', 'Europe', 4, 'Southern Europe', 16, 'Bosnian or Herzegovinian', 44.00000000, 18.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q225'),
(29, 'Botswana', 'BWA', '072', 'BW', '267', 'Gaborone', 'BWP', 'Botswana pula', 'P', '.bw', 'Botswana', 'Africa', 1, 'Southern Africa', 5, 'Motswana, Botswanan', -22.00000000, 24.00000000, '2018-07-21 12:41:03', '2023-08-11 21:01:40', 1, 'Q963'),
(30, 'Bouvet Island', 'BVT', '074', 'BV', '0055', '', 'NOK', 'Norwegian krone', 'ko', '.bv', 'Bouvetøya', '', NULL, '', NULL, 'Bouvet Island', -54.43333333, 3.40000000, '2018-07-21 12:41:03', '2024-12-23 15:33:12', 1, 'Q23408'),
(31, 'Brazil', 'BRA', '076', 'BR', '55', 'Brasilia', 'BRL', 'Brazilian real', 'R$', '.br', 'Brasil', 'Americas', 2, 'South America', 8, 'Brazilian', -10.00000000, -55.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q155'),
(32, 'British Indian Ocean Territory', 'IOT', '086', 'IO', '246', 'Diego Garcia', 'USD', 'United States dollar', '$', '.io', 'British Indian Ocean Territory', 'Africa', 1, 'Eastern Africa', 4, 'BIOT', -6.00000000, 71.50000000, '2018-07-21 12:41:03', '2024-12-19 21:04:08', 1, 'Q43448'),
(33, 'Brunei', 'BRN', '096', 'BN', '673', 'Bandar Seri Begawan', 'BND', 'Brunei dollar', 'B$', '.bn', 'Negara Brunei Darussalam', 'Asia', 3, 'South-Eastern Asia', 13, 'Bruneian', 4.50000000, 114.66666666, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q921'),
(34, 'Bulgaria', 'BGR', '100', 'BG', '359', 'Sofia', 'BGN', 'Bulgarian lev', 'Лв.', '.bg', 'България', 'Europe', 4, 'Eastern Europe', 15, 'Bulgarian', 43.00000000, 25.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q219'),
(35, 'Burkina Faso', 'BFA', '854', 'BF', '226', 'Ouagadougou', 'XOF', 'West African CFA franc', 'CFA', '.bf', 'Burkina Faso', 'Africa', 1, 'Western Africa', 3, 'Burkinabe', 13.00000000, -2.00000000, '2018-07-21 12:41:03', '2023-08-11 21:15:55', 1, 'Q965'),
(36, 'Burundi', 'BDI', '108', 'BI', '257', 'Bujumbura', 'BIF', 'Burundian franc', 'FBu', '.bi', 'Burundi', 'Africa', 1, 'Eastern Africa', 4, 'Burundian', -3.50000000, 30.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q967'),
(37, 'Cambodia', 'KHM', '116', 'KH', '855', 'Phnom Penh', 'KHR', 'Cambodian riel', 'KHR', '.kh', 'Kâmpŭchéa', 'Asia', 3, 'South-Eastern Asia', 13, 'Cambodian', 13.00000000, 105.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q424'),
(38, 'Cameroon', 'CMR', '120', 'CM', '237', 'Yaounde', 'XAF', 'Central African CFA franc', 'FCFA', '.cm', 'Cameroon', 'Africa', 1, 'Middle Africa', 2, 'Cameroonian', 6.00000000, 12.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q1009'),
(39, 'Canada', 'CAN', '124', 'CA', '1', 'Ottawa', 'CAD', 'Canadian dollar', '$', '.ca', 'Canada', 'Americas', 2, 'Northern America', 6, 'Canadian', 60.00000000, -95.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q16'),
(40, 'Cape Verde', 'CPV', '132', 'CV', '238', 'Praia', 'CVE', 'Cape Verdean escudo', '$', '.cv', 'Cabo Verde', 'Africa', 1, 'Western Africa', 3, 'Verdean', 16.00000000, -24.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q1011'),
(41, 'Cayman Islands', 'CYM', '136', 'KY', '1', 'George Town', 'KYD', 'Cayman Islands dollar', '$', '.ky', 'Cayman Islands', 'Americas', 2, 'Caribbean', 7, 'Caymanian', 19.50000000, -80.50000000, '2018-07-21 12:41:03', '2024-12-19 21:04:08', 1, 'Q5785'),
(42, 'Central African Republic', 'CAF', '140', 'CF', '236', 'Bangui', 'XAF', 'Central African CFA franc', 'FCFA', '.cf', 'Ködörösêse tî Bêafrîka', 'Africa', 1, 'Middle Africa', 2, 'Central African', 7.00000000, 21.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q929'),
(43, 'Chad', 'TCD', '148', 'TD', '235', 'N\'Djamena', 'XAF', 'Central African CFA franc', 'FCFA', '.td', 'Tchad', 'Africa', 1, 'Middle Africa', 2, 'Chadian', 15.00000000, 19.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q657'),
(44, 'Chile', 'CHL', '152', 'CL', '56', 'Santiago', 'CLP', 'Chilean peso', '$', '.cl', 'Chile', 'Americas', 2, 'South America', 8, 'Chilean', -30.00000000, -71.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q298'),
(45, 'China', 'CHN', '156', 'CN', '86', 'Beijing', 'CNY', 'Chinese yuan', '¥', '.cn', '中国', 'Asia', 3, 'Eastern Asia', 12, 'Chinese', 35.00000000, 105.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q148'),
(46, 'Christmas Island', 'CXR', '162', 'CX', '61', 'Flying Fish Cove', 'AUD', 'Australian dollar', '$', '.cx', 'Christmas Island', 'Oceania', 5, 'Australia and New Zealand', 19, 'Christmas Island', -10.50000000, 105.66666666, '2018-07-21 12:41:03', '2024-12-19 21:04:08', 1, 'Q31063'),
(47, 'Cocos (Keeling) Islands', 'CCK', '166', 'CC', '61', 'West Island', 'AUD', 'Australian dollar', '$', '.cc', 'Cocos (Keeling) Islands', 'Oceania', 5, 'Australia and New Zealand', 19, 'Cocos Island', -12.50000000, 96.83333333, '2018-07-21 12:41:03', '2024-12-19 21:04:08', 1, 'Q36004'),
(48, 'Colombia', 'COL', '170', 'CO', '57', 'Bogotá', 'COP', 'Colombian peso', '$', '.co', 'Colombia', 'Americas', 2, 'South America', 8, 'Colombian', 4.00000000, -72.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q739'),
(49, 'Comoros', 'COM', '174', 'KM', '269', 'Moroni', 'KMF', 'Comorian franc', 'CF', '.km', 'Komori', 'Africa', 1, 'Eastern Africa', 4, 'Comoran, Comorian', -12.16666666, 44.25000000, '2018-07-21 12:41:03', '2023-08-11 21:15:55', 1, 'Q970'),
(50, 'Congo', 'COG', '178', 'CG', '242', 'Brazzaville', 'XAF', 'Congolese Franc', 'CDF', '.cg', 'République du Congo', 'Africa', 1, 'Middle Africa', 2, 'Congolese', -1.00000000, 15.00000000, '2018-07-21 12:41:03', '2024-12-23 15:55:22', 1, 'Q971'),
(51, 'Democratic Republic of the Congo', 'COD', '180', 'CD', '243', 'Kinshasa', 'CDF', 'Congolese Franc', 'FC', '.cd', 'République démocratique du Congo', 'Africa', 1, 'Middle Africa', 2, 'Congolese', 0.00000000, 25.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q974'),
(52, 'Cook Islands', 'COK', '184', 'CK', '682', 'Avarua', 'NZD', 'New Zealand dollar', '$', '.ck', 'Cook Islands', 'Oceania', 5, 'Polynesia', 22, 'Cook Island', -21.23333333, -159.76666666, '2018-07-21 12:41:03', '2024-12-23 15:33:12', 1, 'Q26988'),
(53, 'Costa Rica', 'CRI', '188', 'CR', '506', 'San Jose', 'CRC', 'Costa Rican colón', '₡', '.cr', 'Costa Rica', 'Americas', 2, 'Central America', 9, 'Costa Rican', 10.00000000, -84.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q800'),
(54, 'Cote D\'Ivoire (Ivory Coast)', 'CIV', '384', 'CI', '225', 'Yamoussoukro', 'XOF', 'West African CFA franc', 'CFA', '.ci', NULL, 'Africa', 1, 'Western Africa', 3, 'Ivorian', 8.00000000, -5.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q1008'),
(55, 'Croatia', 'HRV', '191', 'HR', '385', 'Zagreb', 'EUR', 'Euro', '€', '.hr', 'Hrvatska', 'Europe', 4, 'Southern Europe', 16, 'Croatian', 45.16666666, 15.50000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q224'),
(56, 'Cuba', 'CUB', '192', 'CU', '53', 'Havana', 'CUP', 'Cuban peso', '$', '.cu', 'Cuba', 'Americas', 2, 'Caribbean', 7, 'Cuban', 21.50000000, -80.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q241'),
(57, 'Cyprus', 'CYP', '196', 'CY', '357', 'Nicosia', 'EUR', 'Euro', '€', '.cy', 'Κύπρος', 'Europe', 4, 'Southern Europe', 16, 'Cypriot', 35.00000000, 33.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q229'),
(58, 'Czech Republic', 'CZE', '203', 'CZ', '420', 'Prague', 'CZK', 'Czech koruna', 'Kč', '.cz', 'Česká republika', 'Europe', 4, 'Eastern Europe', 15, 'Czech', 49.75000000, 15.50000000, '2018-07-21 12:41:03', '2024-09-05 17:11:18', 1, 'Q213'),
(59, 'Denmark', 'DNK', '208', 'DK', '45', 'Copenhagen', 'DKK', 'Danish krone', 'Kr.', '.dk', 'Danmark', 'Europe', 4, 'Northern Europe', 18, 'Danish', 56.00000000, 10.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q35'),
(60, 'Djibouti', 'DJI', '262', 'DJ', '253', 'Djibouti', 'DJF', 'Djiboutian franc', 'Fdj', '.dj', 'Djibouti', 'Africa', 1, 'Eastern Africa', 4, 'Djiboutian', 11.50000000, 43.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q977'),
(61, 'Dominica', 'DMA', '212', 'DM', '1', 'Roseau', 'XCD', 'Eastern Caribbean dollar', '$', '.dm', 'Dominica', 'Americas', 2, 'Caribbean', 7, 'Dominican', 15.41666666, -61.33333333, '2018-07-21 12:41:03', '2024-09-05 16:47:03', 1, 'Q784'),
(62, 'Dominican Republic', 'DOM', '214', 'DO', '1', 'Santo Domingo', 'DOP', 'Dominican peso', '$', '.do', 'República Dominicana', 'Americas', 2, 'Caribbean', 7, 'Dominican', 19.00000000, -70.66666666, '2018-07-21 12:41:03', '2024-09-05 16:47:03', 1, 'Q786'),
(63, 'Timor-Leste', 'TLS', '626', 'TL', '670', 'Dili', 'USD', 'United States dollar', '$', '.tl', 'Timor-Leste', 'Asia', 3, 'South-Eastern Asia', 13, 'Timorese', -8.83333333, 125.91666666, '2018-07-21 12:41:03', '2023-08-11 21:15:55', 1, 'Q574'),
(64, 'Ecuador', 'ECU', '218', 'EC', '593', 'Quito', 'USD', 'United States dollar', '$', '.ec', 'Ecuador', 'Americas', 2, 'South America', 8, 'Ecuadorian', -2.00000000, -77.50000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q736'),
(65, 'Egypt', 'EGY', '818', 'EG', '20', 'Cairo', 'EGP', 'Egyptian pound', 'ج.م', '.eg', 'مصر‎', 'Africa', 1, 'Northern Africa', 1, 'Egyptian', 27.00000000, 30.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q79'),
(66, 'El Salvador', 'SLV', '222', 'SV', '503', 'San Salvador', 'USD', 'United States dollar', '$', '.sv', 'El Salvador', 'Americas', 2, 'Central America', 9, 'Salvadoran', 13.83333333, -88.91666666, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q792'),
(67, 'Equatorial Guinea', 'GNQ', '226', 'GQ', '240', 'Malabo', 'XAF', 'Central African CFA franc', 'FCFA', '.gq', 'Guinea Ecuatorial', 'Africa', 1, 'Middle Africa', 2, 'Equatorial Guinean, Equatoguinean', 2.00000000, 10.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q983'),
(68, 'Eritrea', 'ERI', '232', 'ER', '291', 'Asmara', 'ERN', 'Eritrean nakfa', 'Nfk', '.er', 'ኤርትራ', 'Africa', 1, 'Eastern Africa', 4, 'Eritrean', 15.00000000, 39.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q986'),
(69, 'Estonia', 'EST', '233', 'EE', '372', 'Tallinn', 'EUR', 'Euro', '€', '.ee', 'Eesti', 'Europe', 4, 'Northern Europe', 18, 'Estonian', 59.00000000, 26.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q191'),
(70, 'Ethiopia', 'ETH', '231', 'ET', '251', 'Addis Ababa', 'ETB', 'Ethiopian birr', 'Nkf', '.et', 'ኢትዮጵያ', 'Africa', 1, 'Eastern Africa', 4, 'Ethiopian', 8.00000000, 38.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q115'),
(71, 'Falkland Islands', 'FLK', '238', 'FK', '500', 'Stanley', 'FKP', 'Falkland Islands pound', '£', '.fk', 'Falkland Islands', 'Americas', 2, 'South America', 8, 'Falkland Island', -51.75000000, -59.00000000, '2018-07-21 12:41:03', '2024-12-19 21:04:08', 1, 'Q9648'),
(72, 'Faroe Islands', 'FRO', '234', 'FO', '298', 'Torshavn', 'DKK', 'Danish krone', 'Kr.', '.fo', 'Føroyar', 'Europe', 4, 'Northern Europe', 18, 'Faroese', 62.00000000, -7.00000000, '2018-07-21 12:41:03', '2024-12-19 21:04:08', 1, 'Q4628'),
(73, 'Fiji Islands', 'FJI', '242', 'FJ', '679', 'Suva', 'FJD', 'Fijian dollar', 'FJ$', '.fj', 'Fiji', 'Oceania', 5, 'Melanesia', 20, 'Fijian', -18.00000000, 175.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q712'),
(74, 'Finland', 'FIN', '246', 'FI', '358', 'Helsinki', 'EUR', 'Euro', '€', '.fi', 'Suomi', 'Europe', 4, 'Northern Europe', 18, 'Finnish', 64.00000000, 26.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q33'),
(75, 'France', 'FRA', '250', 'FR', '33', 'Paris', 'EUR', 'Euro', '€', '.fr', 'France', 'Europe', 4, 'Western Europe', 17, 'French', 46.00000000, 2.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q142'),
(76, 'French Guiana', 'GUF', '254', 'GF', '594', 'Cayenne', 'EUR', 'Euro', '€', '.gf', 'Guyane française', 'Americas', 2, 'South America', 8, 'French Guianese', 4.00000000, -53.00000000, '2018-07-21 12:41:03', '2024-12-19 21:04:08', 1, 'Q3769'),
(77, 'French Polynesia', 'PYF', '258', 'PF', '689', 'Papeete', 'XPF', 'CFP franc', '₣', '.pf', 'Polynésie française', 'Oceania', 5, 'Polynesia', 22, 'French Polynesia', -15.00000000, -140.00000000, '2018-07-21 12:41:03', '2024-12-19 21:04:08', 1, 'Q30971'),
(78, 'French Southern Territories', 'ATF', '260', 'TF', '262', 'Port-aux-Francais', 'EUR', 'Euro', '€', '.tf', 'Territoire des Terres australes et antarctiques fr', 'Africa', 1, 'Southern Africa', 5, 'French Southern Territories', -49.25000000, 69.16700000, '2018-07-21 12:41:03', '2024-12-19 21:04:08', 1, 'Q129003'),
(79, 'Gabon', 'GAB', '266', 'GA', '241', 'Libreville', 'XAF', 'Central African CFA franc', 'FCFA', '.ga', 'Gabon', 'Africa', 1, 'Middle Africa', 2, 'Gabonese', -1.00000000, 11.75000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q1000'),
(80, 'The Gambia ', 'GMB', '270', 'GM', '220', 'Banjul', 'GMD', 'Gambian dalasi', 'D', '.gm', 'Gambia', 'Africa', 1, 'Western Africa', 3, 'Gambian', 13.46666666, -16.56666666, '2018-07-21 12:41:03', '2024-09-03 16:53:28', 1, 'Q1005'),
(81, 'Georgia', 'GEO', '268', 'GE', '995', 'Tbilisi', 'GEL', 'Georgian lari', 'ლ', '.ge', 'საქართველო', 'Asia', 3, 'Western Asia', 11, 'Georgian', 42.00000000, 43.50000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q230'),
(82, 'Germany', 'DEU', '276', 'DE', '49', 'Berlin', 'EUR', 'Euro', '€', '.de', 'Deutschland', 'Europe', 4, 'Western Europe', 17, 'German', 51.00000000, 9.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q183'),
(83, 'Ghana', 'GHA', '288', 'GH', '233', 'Accra', 'GHS', 'Ghanaian cedi', 'GH₵', '.gh', 'Ghana', 'Africa', 1, 'Western Africa', 3, 'Ghanaian', 8.00000000, -2.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q117'),
(84, 'Gibraltar', 'GIB', '292', 'GI', '350', 'Gibraltar', 'GIP', 'Gibraltar pound', '£', '.gi', 'Gibraltar', 'Europe', 4, 'Southern Europe', 16, 'Gibraltar', 36.13333333, -5.35000000, '2018-07-21 12:41:03', '2024-12-19 21:04:08', 1, 'Q1410'),
(85, 'Greece', 'GRC', '300', 'GR', '30', 'Athens', 'EUR', 'Euro', '€', '.gr', 'Ελλάδα', 'Europe', 4, 'Southern Europe', 16, 'Greek, Hellenic', 39.00000000, 22.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q41'),
(86, 'Greenland', 'GRL', '304', 'GL', '299', 'Nuuk', 'DKK', 'Danish krone', 'Kr.', '.gl', 'Kalaallit Nunaat', 'Americas', 2, 'Northern America', 6, 'Greenlandic', 72.00000000, -40.00000000, '2018-07-21 12:41:03', '2024-12-19 21:04:08', 1, 'Q223'),
(87, 'Grenada', 'GRD', '308', 'GD', '1', 'St. George\'s', 'XCD', 'Eastern Caribbean dollar', '$', '.gd', 'Grenada', 'Americas', 2, 'Caribbean', 7, 'Grenadian', 12.11666666, -61.66666666, '2018-07-21 12:41:03', '2024-09-05 16:47:03', 1, 'Q769'),
(88, 'Guadeloupe', 'GLP', '312', 'GP', '590', 'Basse-Terre', 'EUR', 'Euro', '€', '.gp', 'Guadeloupe', 'Americas', 2, 'Caribbean', 7, 'Guadeloupe', 16.25000000, -61.58333300, '2018-07-21 12:41:03', '2024-12-19 21:04:08', 1, 'Q17012'),
(89, 'Guam', 'GUM', '316', 'GU', '1', 'Hagatna', 'USD', 'United States dollar', '$', '.gu', 'Guam', 'Oceania', 5, 'Micronesia', 21, 'Guamanian, Guambat', 13.46666666, 144.78333333, '2018-07-21 12:41:03', '2024-12-23 15:33:12', 1, 'Q16635'),
(90, 'Guatemala', 'GTM', '320', 'GT', '502', 'Guatemala City', 'GTQ', 'Guatemalan quetzal', 'Q', '.gt', 'Guatemala', 'Americas', 2, 'Central America', 9, 'Guatemalan', 15.50000000, -90.25000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q774'),
(91, 'Guernsey', 'GGY', '831', 'GG', '44', 'St Peter Port', 'GBP', 'British pound', '£', '.gg', 'Guernsey', 'Europe', 4, 'Northern Europe', 18, 'Channel Island', 49.46666666, -2.58333333, '2018-07-21 12:41:03', '2025-05-05 17:57:05', 1, 'Q25230'),
(92, 'Guinea', 'GIN', '324', 'GN', '224', 'Conakry', 'GNF', 'Guinean franc', 'FG', '.gn', 'Guinée', 'Africa', 1, 'Western Africa', 3, 'Guinean', 11.00000000, -10.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q1006'),
(93, 'Guinea-Bissau', 'GNB', '624', 'GW', '245', 'Bissau', 'XOF', 'West African CFA franc', 'CFA', '.gw', 'Guiné-Bissau', 'Africa', 1, 'Western Africa', 3, 'Bissau-Guinean', 12.00000000, -15.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q1007'),
(94, 'Guyana', 'GUY', '328', 'GY', '592', 'Georgetown', 'GYD', 'Guyanese dollar', '$', '.gy', 'Guyana', 'Americas', 2, 'South America', 8, 'Guyanese', 5.00000000, -59.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q734'),
(95, 'Haiti', 'HTI', '332', 'HT', '509', 'Port-au-Prince', 'HTG', 'Haitian gourde', 'G', '.ht', 'Haïti', 'Americas', 2, 'Caribbean', 7, 'Haitian', 19.00000000, -72.41666666, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q790'),
(96, 'Heard Island and McDonald Islands', 'HMD', '334', 'HM', '672', '', 'AUD', 'Australian dollar', '$', '.hm', 'Heard Island and McDonald Islands', '', NULL, '', NULL, 'Heard Island or McDonald Islands', -53.10000000, 72.51666666, '2018-07-21 12:41:03', '2024-12-19 21:04:08', 1, 'Q131198'),
(97, 'Honduras', 'HND', '340', 'HN', '504', 'Tegucigalpa', 'HNL', 'Honduran lempira', 'L', '.hn', 'Honduras', 'Americas', 2, 'Central America', 9, 'Honduran', 15.00000000, -86.50000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q783'),
(98, 'Hong Kong S.A.R.', 'HKG', '344', 'HK', '852', 'Hong Kong', 'HKD', 'Hong Kong dollar', '$', '.hk', '香港', 'Asia', 3, 'Eastern Asia', 12, 'Hong Kong, Hong Kongese', 22.25000000, 114.16666666, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q8646'),
(99, 'Hungary', 'HUN', '348', 'HU', '36', 'Budapest', 'HUF', 'Hungarian forint', 'Ft', '.hu', 'Magyarország', 'Europe', 4, 'Eastern Europe', 15, 'Hungarian, Magyar', 47.00000000, 20.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q28'),
(100, 'Iceland', 'ISL', '352', 'IS', '354', 'Reykjavik', 'ISK', 'Icelandic króna', 'ko', '.is', 'Ísland', 'Europe', 4, 'Northern Europe', 18, 'Icelandic', 65.00000000, -18.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q189'),
(101, 'India', 'IND', '356', 'IN', '91', 'New Delhi', 'INR', 'Indian rupee', '₹', '.in', 'भारत', 'Asia', 3, 'Southern Asia', 14, 'Indian', 20.00000000, 77.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q668'),
(102, 'Indonesia', 'IDN', '360', 'ID', '62', 'Jakarta', 'IDR', 'Indonesian rupiah', 'Rp', '.id', 'Indonesia', 'Asia', 3, 'South-Eastern Asia', 13, 'Indonesian', -5.00000000, 120.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q252'),
(103, 'Iran', 'IRN', '364', 'IR', '98', 'Tehran', 'IRR', 'Iranian rial', '﷼', '.ir', 'ایران', 'Asia', 3, 'Southern Asia', 14, 'Iranian, Persian', 32.00000000, 53.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q794'),
(104, 'Iraq', 'IRQ', '368', 'IQ', '964', 'Baghdad', 'IQD', 'Iraqi dinar', 'د.ع', '.iq', 'العراق', 'Asia', 3, 'Western Asia', 11, 'Iraqi', 33.00000000, 44.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q796'),
(105, 'Ireland', 'IRL', '372', 'IE', '353', 'Dublin', 'EUR', 'Euro', '€', '.ie', 'Éire', 'Europe', 4, 'Northern Europe', 18, 'Irish', 53.00000000, -8.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q27'),
(106, 'Israel', 'ISR', '376', 'IL', '972', 'Jerusalem', 'ILS', 'Israeli new shekel', '₪', '.il', 'יִשְׂרָאֵל', 'Asia', 3, 'Western Asia', 11, 'Israeli', 31.50000000, 34.75000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q801'),
(107, 'Italy', 'ITA', '380', 'IT', '39', 'Rome', 'EUR', 'Euro', '€', '.it', 'Italia', 'Europe', 4, 'Southern Europe', 16, 'Italian', 42.83333333, 12.83333333, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q38'),
(108, 'Jamaica', 'JAM', '388', 'JM', '1', 'Kingston', 'JMD', 'Jamaican dollar', 'J$', '.jm', 'Jamaica', 'Americas', 2, 'Caribbean', 7, 'Jamaican', 18.25000000, -77.50000000, '2018-07-21 12:41:03', '2024-09-05 16:47:03', 1, 'Q766'),
(109, 'Japan', 'JPN', '392', 'JP', '81', 'Tokyo', 'JPY', 'Japanese yen', '¥', '.jp', '日本', 'Asia', 3, 'Eastern Asia', 12, 'Japanese', 36.00000000, 138.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q17'),
(110, 'Jersey', 'JEY', '832', 'JE', '44', 'Saint Helier', 'GBP', 'British pound', '£', '.je', 'Jersey', 'Europe', 4, 'Northern Europe', 18, 'Channel Island', 49.25000000, -2.16666666, '2018-07-21 12:41:03', '2024-09-05 16:47:03', 1, 'Q785'),
(111, 'Jordan', 'JOR', '400', 'JO', '962', 'Amman', 'JOD', 'Jordanian dinar', 'ا.د', '.jo', 'الأردن', 'Asia', 3, 'Western Asia', 11, 'Jordanian', 31.00000000, 36.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q810'),
(112, 'Kazakhstan', 'KAZ', '398', 'KZ', '7', 'Astana', 'KZT', 'Kazakhstani tenge', 'лв', '.kz', 'Қазақстан', 'Asia', 3, 'Central Asia', 10, 'Kazakhstani, Kazakh', 48.00000000, 68.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q232'),
(113, 'Kenya', 'KEN', '404', 'KE', '254', 'Nairobi', 'KES', 'Kenyan shilling', 'KSh', '.ke', 'Kenya', 'Africa', 1, 'Eastern Africa', 4, 'Kenyan', 1.00000000, 38.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q114'),
(114, 'Kiribati', 'KIR', '296', 'KI', '686', 'Tarawa', 'AUD', 'Australian dollar', '$', '.ki', 'Kiribati', 'Oceania', 5, 'Micronesia', 21, 'I-Kiribati', 1.41666666, 173.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q710'),
(115, 'North Korea', 'PRK', '408', 'KP', '850', 'Pyongyang', 'KPW', 'North Korean Won', '₩', '.kp', '북한', 'Asia', 3, 'Eastern Asia', 12, 'North Korean', 40.00000000, 127.00000000, '2018-07-21 12:41:03', '2023-08-11 21:15:55', 1, 'Q423'),
(116, 'South Korea', 'KOR', '410', 'KR', '82', 'Seoul', 'KRW', 'Won', '₩', '.kr', '대한민국', 'Asia', 3, 'Eastern Asia', 12, 'South Korean', 37.00000000, 127.50000000, '2018-07-21 12:41:03', '2023-08-11 21:15:55', 1, 'Q884'),
(117, 'Kuwait', 'KWT', '414', 'KW', '965', 'Kuwait City', 'KWD', 'Kuwaiti dinar', 'ك.د', '.kw', 'الكويت', 'Asia', 3, 'Western Asia', 11, 'Kuwaiti', 29.50000000, 45.75000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q817'),
(118, 'Kyrgyzstan', 'KGZ', '417', 'KG', '996', 'Bishkek', 'KGS', 'Kyrgyzstani som', 'лв', '.kg', 'Кыргызстан', 'Asia', 3, 'Central Asia', 10, 'Kyrgyzstani, Kyrgyz, Kirgiz, Kirghiz', 41.00000000, 75.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q813'),
(119, 'Laos', 'LAO', '418', 'LA', '856', 'Vientiane', 'LAK', 'Lao kip', '₭', '.la', 'ສປປລາວ', 'Asia', 3, 'South-Eastern Asia', 13, 'Lao, Laotian', 18.00000000, 105.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q819'),
(120, 'Latvia', 'LVA', '428', 'LV', '371', 'Riga', 'EUR', 'Euro', '€', '.lv', 'Latvija', 'Europe', 4, 'Northern Europe', 18, 'Latvian', 57.00000000, 25.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q211'),
(121, 'Lebanon', 'LBN', '422', 'LB', '961', 'Beirut', 'LBP', 'Lebanese pound', '£', '.lb', 'لبنان', 'Asia', 3, 'Western Asia', 11, 'Lebanese', 33.83333333, 35.83333333, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q822'),
(122, 'Lesotho', 'LSO', '426', 'LS', '266', 'Maseru', 'LSL', 'Lesotho loti', 'L', '.ls', 'Lesotho', 'Africa', 1, 'Southern Africa', 5, 'Basotho', -29.50000000, 28.50000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q1013'),
(123, 'Liberia', 'LBR', '430', 'LR', '231', 'Monrovia', 'LRD', 'Liberian dollar', '$', '.lr', 'Liberia', 'Africa', 1, 'Western Africa', 3, 'Liberian', 6.50000000, -9.50000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q1014'),
(124, 'Libya', 'LBY', '434', 'LY', '218', 'Tripolis', 'LYD', 'Libyan dinar', 'د.ل', '.ly', '‏ليبيا', 'Africa', 1, 'Northern Africa', 1, 'Libyan', 25.00000000, 17.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q1016'),
(125, 'Liechtenstein', 'LIE', '438', 'LI', '423', 'Vaduz', 'CHF', 'Swiss franc', 'CHf', '.li', 'Liechtenstein', 'Europe', 4, 'Western Europe', 17, 'Liechtenstein', 47.26666666, 9.53333333, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q347'),
(126, 'Lithuania', 'LTU', '440', 'LT', '370', 'Vilnius', 'EUR', 'Euro', '€', '.lt', 'Lietuva', 'Europe', 4, 'Northern Europe', 18, 'Lithuanian', 56.00000000, 24.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q37'),
(127, 'Luxembourg', 'LUX', '442', 'LU', '352', 'Luxembourg', 'EUR', 'Euro', '€', '.lu', 'Luxembourg', 'Europe', 4, 'Western Europe', 17, 'Luxembourg, Luxembourgish', 49.75000000, 6.16666666, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q32'),
(128, 'Macau S.A.R.', 'MAC', '446', 'MO', '853', 'Macao', 'MOP', 'Macanese pataca', '$', '.mo', '澳門', 'Asia', 3, 'Eastern Asia', 12, 'Macanese, Chinese', 22.16666666, 113.55000000, '2018-07-21 12:41:03', '2024-12-19 21:04:08', 1, 'Q14773'),
(129, 'North Macedonia', 'MKD', '807', 'MK', '389', 'Skopje', 'MKD', 'Denar', 'ден', '.mk', 'Северна Македонија', 'Europe', 4, 'Southern Europe', 16, 'Macedonian', 41.83333333, 22.00000000, '2018-07-21 12:41:03', '2023-08-11 21:15:55', 1, 'Q221'),
(130, 'Madagascar', 'MDG', '450', 'MG', '261', 'Antananarivo', 'MGA', 'Malagasy ariary', 'Ar', '.mg', 'Madagasikara', 'Africa', 1, 'Eastern Africa', 4, 'Malagasy', -20.00000000, 47.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q1019'),
(131, 'Malawi', 'MWI', '454', 'MW', '265', 'Lilongwe', 'MWK', 'Malawian kwacha', 'MK', '.mw', 'Malawi', 'Africa', 1, 'Eastern Africa', 4, 'Malawian', -13.50000000, 34.00000000, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q1020'),
(132, 'Malaysia', 'MYS', '458', 'MY', '60', 'Kuala Lumpur', 'MYR', 'Malaysian ringgit', 'RM', '.my', 'Malaysia', 'Asia', 3, 'South-Eastern Asia', 13, 'Malaysian', 2.50000000, 112.50000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q833'),
(133, 'Maldives', 'MDV', '462', 'MV', '960', 'Male', 'MVR', 'Maldivian rufiyaa', 'Rf', '.mv', 'Maldives', 'Asia', 3, 'Southern Asia', 14, 'Maldivian', 3.25000000, 73.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q826'),
(134, 'Mali', 'MLI', '466', 'ML', '223', 'Bamako', 'XOF', 'West African CFA franc', 'CFA', '.ml', 'Mali', 'Africa', 1, 'Western Africa', 3, 'Malian, Malinese', 17.00000000, -4.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q912'),
(135, 'Malta', 'MLT', '470', 'MT', '356', 'Valletta', 'EUR', 'Euro', '€', '.mt', 'Malta', 'Europe', 4, 'Southern Europe', 16, 'Maltese', 35.83333333, 14.58333333, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q233'),
(136, 'Man (Isle of)', 'IMN', '833', 'IM', '44', 'Douglas, Isle of Man', 'GBP', 'British pound', '£', '.im', 'Isle of Man', 'Europe', 4, 'Northern Europe', 18, 'Manx', 54.25000000, -4.50000000, '2018-07-21 12:41:03', '2025-05-05 17:57:05', 1, 'Q9676'),
(137, 'Marshall Islands', 'MHL', '584', 'MH', '692', 'Majuro', 'USD', 'United States dollar', '$', '.mh', 'M̧ajeļ', 'Oceania', 5, 'Micronesia', 21, 'Marshallese', 9.00000000, 168.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q709'),
(138, 'Martinique', 'MTQ', '474', 'MQ', '596', 'Fort-de-France', 'EUR', 'Euro', '€', '.mq', 'Martinique', 'Americas', 2, 'Caribbean', 7, 'Martiniquais, Martinican', 14.66666700, -61.00000000, '2018-07-21 12:41:03', '2024-12-19 21:04:08', 1, 'Q17054'),
(139, 'Mauritania', 'MRT', '478', 'MR', '222', 'Nouakchott', 'MRU', 'Mauritanian ouguiya', 'UM', '.mr', 'موريتانيا', 'Africa', 1, 'Western Africa', 3, 'Mauritanian', 20.00000000, -12.00000000, '2018-07-21 12:41:03', '2025-03-22 20:09:58', 1, 'Q1025'),
(140, 'Mauritius', 'MUS', '480', 'MU', '230', 'Port Louis', 'MUR', 'Mauritian rupee', '₨', '.mu', 'Maurice', 'Africa', 1, 'Eastern Africa', 4, 'Mauritian', -20.28333333, 57.55000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q1027'),
(141, 'Mayotte', 'MYT', '175', 'YT', '262', 'Mamoudzou', 'EUR', 'Euro', '€', '.yt', 'Mayotte', 'Africa', 1, 'Eastern Africa', 4, 'Mahoran', -12.83333333, 45.16666666, '2018-07-21 12:41:03', '2024-12-19 21:04:08', 1, 'Q17063'),
(142, 'Mexico', 'MEX', '484', 'MX', '52', 'Ciudad de México', 'MXN', 'Mexican peso', '$', '.mx', 'México', 'Americas', 2, 'Northern America', 6, 'Mexican', 23.00000000, -102.00000000, '2018-07-21 12:41:03', '2025-05-01 20:10:06', 1, 'Q96'),
(143, 'Micronesia', 'FSM', '583', 'FM', '691', 'Palikir', 'USD', 'United States dollar', '$', '.fm', 'Micronesia', 'Oceania', 5, 'Micronesia', 21, 'Micronesian', 6.91666666, 158.25000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q702'),
(144, 'Moldova', 'MDA', '498', 'MD', '373', 'Chisinau', 'MDL', 'Moldovan leu', 'L', '.md', 'Moldova', 'Europe', 4, 'Eastern Europe', 15, 'Moldovan', 47.00000000, 29.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q217'),
(145, 'Monaco', 'MCO', '492', 'MC', '377', 'Monaco', 'EUR', 'Euro', '€', '.mc', 'Monaco', 'Europe', 4, 'Western Europe', 17, 'Monegasque, Monacan', 43.73333333, 7.40000000, '2018-07-21 12:41:03', '2023-08-11 21:15:55', 1, 'Q235'),
(146, 'Mongolia', 'MNG', '496', 'MN', '976', 'Ulan Bator', 'MNT', 'Mongolian tögrög', '₮', '.mn', 'Монгол улс', 'Asia', 3, 'Eastern Asia', 12, 'Mongolian', 46.00000000, 105.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q711'),
(147, 'Montenegro', 'MNE', '499', 'ME', '382', 'Podgorica', 'EUR', 'Euro', '€', '.me', 'Црна Гора', 'Europe', 4, 'Southern Europe', 16, 'Montenegrin', 42.50000000, 19.30000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q236'),
(148, 'Montserrat', 'MSR', '500', 'MS', '1', 'Plymouth', 'XCD', 'Eastern Caribbean dollar', '$', '.ms', 'Montserrat', 'Americas', 2, 'Caribbean', 7, 'Montserratian', 16.75000000, -62.20000000, '2018-07-21 12:41:03', '2024-12-19 21:04:08', 1, 'Q13353'),
(149, 'Morocco', 'MAR', '504', 'MA', '212', 'Rabat', 'MAD', 'Moroccan dirham', 'DH', '.ma', 'المغرب', 'Africa', 1, 'Northern Africa', 1, 'Moroccan', 32.00000000, -5.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q1028'),
(150, 'Mozambique', 'MOZ', '508', 'MZ', '258', 'Maputo', 'MZN', 'Mozambican metical', 'MT', '.mz', 'Moçambique', 'Africa', 1, 'Eastern Africa', 4, 'Mozambican', -18.25000000, 35.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q1029'),
(151, 'Myanmar', 'MMR', '104', 'MM', '95', 'Nay Pyi Taw', 'MMK', 'Burmese kyat', 'K', '.mm', 'မြန်မာ', 'Asia', 3, 'South-Eastern Asia', 13, 'Burmese', 22.00000000, 98.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q836'),
(152, 'Namibia', 'NAM', '516', 'NA', '264', 'Windhoek', 'NAD', 'Namibian dollar', '$', '.na', 'Namibia', 'Africa', 1, 'Southern Africa', 5, 'Namibian', -22.00000000, 17.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q1030'),
(153, 'Nauru', 'NRU', '520', 'NR', '674', 'Yaren', 'AUD', 'Australian dollar', '$', '.nr', 'Nauru', 'Oceania', 5, 'Micronesia', 21, 'Nauruan', -0.53333333, 166.91666666, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q697'),
(154, 'Nepal', 'NPL', '524', 'NP', '977', 'Kathmandu', 'NPR', 'Nepalese rupee', '₨', '.np', 'नपल', 'Asia', 3, 'Southern Asia', 14, 'Nepali, Nepalese', 28.00000000, 84.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q837'),
(155, 'Bonaire, Sint Eustatius and Saba', 'BES', '535', 'BQ', '599', 'Kralendijk', 'USD', 'United States dollar', '$', '.an', 'Caribisch Nederland', 'Americas', 2, 'Caribbean', 7, 'Bonaire', 12.15000000, -68.26666700, '2018-07-21 12:41:03', '2023-08-09 02:34:58', 1, 'Q27561'),
(156, 'Netherlands', 'NLD', '528', 'NL', '31', 'Amsterdam', 'EUR', 'Euro', '€', '.nl', 'Nederland', 'Europe', 4, 'Western Europe', 17, 'Dutch, Netherlandic', 52.50000000, 5.75000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q55'),
(157, 'New Caledonia', 'NCL', '540', 'NC', '687', 'Noumea', 'XPF', 'CFP franc', '₣', '.nc', 'Nouvelle-Calédonie', 'Oceania', 5, 'Melanesia', 20, 'New Caledonian', -21.50000000, 165.50000000, '2018-07-21 12:41:03', '2024-12-19 21:04:08', 1, 'Q33788'),
(158, 'New Zealand', 'NZL', '554', 'NZ', '64', 'Wellington', 'NZD', 'New Zealand dollar', '$', '.nz', 'New Zealand', 'Oceania', 5, 'Australia and New Zealand', 19, 'New Zealand, NZ', -41.00000000, 174.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q664'),
(159, 'Nicaragua', 'NIC', '558', 'NI', '505', 'Managua', 'NIO', 'Nicaraguan córdoba', 'C$', '.ni', 'Nicaragua', 'Americas', 2, 'Central America', 9, 'Nicaraguan', 13.00000000, -85.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q811'),
(160, 'Niger', 'NER', '562', 'NE', '227', 'Niamey', 'XOF', 'West African CFA franc', 'CFA', '.ne', 'Niger', 'Africa', 1, 'Western Africa', 3, 'Nigerien', 16.00000000, 8.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q1032'),
(161, 'Nigeria', 'NGA', '566', 'NG', '234', 'Abuja', 'NGN', 'Nigerian naira', '₦', '.ng', 'Nigeria', 'Africa', 1, 'Western Africa', 3, 'Nigerian', 10.00000000, 8.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q1033'),
(162, 'Niue', 'NIU', '570', 'NU', '683', 'Alofi', 'NZD', 'New Zealand dollar', '$', '.nu', 'Niuē', 'Oceania', 5, 'Polynesia', 22, 'Niuean', -19.03333333, -169.86666666, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q34020'),
(163, 'Norfolk Island', 'NFK', '574', 'NF', '672', 'Kingston', 'AUD', 'Australian dollar', '$', '.nf', 'Norfolk Island', 'Oceania', 5, 'Australia and New Zealand', 19, 'Norfolk Island', -29.03333333, 167.95000000, '2018-07-21 12:41:03', '2024-12-19 21:04:08', 1, 'Q31057'),
(164, 'Northern Mariana Islands', 'MNP', '580', 'MP', '1', 'Saipan', 'USD', 'United States dollar', '$', '.mp', 'Northern Mariana Islands', 'Oceania', 5, 'Micronesia', 21, 'Northern Marianan', 15.20000000, 145.75000000, '2018-07-21 12:41:03', '2024-12-19 21:04:08', 1, 'Q16644'),
(165, 'Norway', 'NOR', '578', 'NO', '47', 'Oslo', 'NOK', 'Norwegian krone', 'ko', '.no', 'Norge', 'Europe', 4, 'Northern Europe', 18, 'Norwegian', 62.00000000, 10.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q20'),
(166, 'Oman', 'OMN', '512', 'OM', '968', 'Muscat', 'OMR', 'Omani rial', '.ع.ر', '.om', 'عمان', 'Asia', 3, 'Western Asia', 11, 'Omani', 21.00000000, 57.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q842'),
(167, 'Pakistan', 'PAK', '586', 'PK', '92', 'Islamabad', 'PKR', 'Pakistani rupee', '₨', '.pk', 'پاکستان', 'Asia', 3, 'Southern Asia', 14, 'Pakistani', 30.00000000, 70.00000000, '2018-07-21 12:41:03', '2024-12-23 15:55:53', 1, 'Q843'),
(168, 'Palau', 'PLW', '585', 'PW', '680', 'Melekeok', 'USD', 'United States dollar', '$', '.pw', 'Palau', 'Oceania', 5, 'Micronesia', 21, 'Palauan', 7.50000000, 134.50000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q695'),
(169, 'Palestinian Territory Occupied', 'PSE', '275', 'PS', '970', 'East Jerusalem', 'ILS', 'Israeli new shekel', '₪', '.ps', 'فلسطين', 'Asia', 3, 'Western Asia', 11, 'Palestinian', 31.90000000, 35.20000000, '2018-07-21 12:41:03', '2025-05-05 17:57:05', 1, 'Q407199'),
(170, 'Panama', 'PAN', '591', 'PA', '507', 'Panama City', 'PAB', 'Panamanian balboa', 'B/.', '.pa', 'Panamá', 'Americas', 2, 'Central America', 9, 'Panamanian', 9.00000000, -80.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q804'),
(171, 'Papua New Guinea', 'PNG', '598', 'PG', '675', 'Port Moresby', 'PGK', 'Papua New Guinean kina', 'K', '.pg', 'Papua Niugini', 'Oceania', 5, 'Melanesia', 20, 'Papua New Guinean, Papuan', -6.00000000, 147.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q691'),
(172, 'Paraguay', 'PRY', '600', 'PY', '595', 'Asuncion', 'PYG', 'Paraguayan guarani', '₲', '.py', 'Paraguay', 'Americas', 2, 'South America', 8, 'Paraguayan', -23.00000000, -58.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q733'),
(173, 'Peru', 'PER', '604', 'PE', '51', 'Lima', 'PEN', 'Peruvian sol', 'S/.', '.pe', 'Perú', 'Americas', 2, 'South America', 8, 'Peruvian', -10.00000000, -76.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q419'),
(174, 'Philippines', 'PHL', '608', 'PH', '63', 'Manila', 'PHP', 'Philippine peso', '₱', '.ph', 'Pilipinas', 'Asia', 3, 'South-Eastern Asia', 13, 'Philippine, Filipino', 13.00000000, 122.00000000, '2018-07-21 12:41:03', '2023-08-11 21:15:55', 1, 'Q928'),
(175, 'Pitcairn Island', 'PCN', '612', 'PN', '870', 'Adamstown', 'NZD', 'New Zealand dollar', '$', '.pn', 'Pitcairn Islands', 'Oceania', 5, 'Polynesia', 22, 'Pitcairn Island', -25.06666666, -130.10000000, '2018-07-21 12:41:03', '2024-12-19 21:04:08', 1, 'Q1779748'),
(176, 'Poland', 'POL', '616', 'PL', '48', 'Warsaw', 'PLN', 'Polish złoty', 'zł', '.pl', 'Polska', 'Europe', 4, 'Eastern Europe', 15, 'Polish', 52.00000000, 20.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q36'),
(177, 'Portugal', 'PRT', '620', 'PT', '351', 'Lisbon', 'EUR', 'Euro', '€', '.pt', 'Portugal', 'Europe', 4, 'Southern Europe', 16, 'Portuguese', 39.50000000, -8.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q45'),
(178, 'Puerto Rico', 'PRI', '630', 'PR', '1', 'San Juan', 'USD', 'United States dollar', '$', '.pr', 'Puerto Rico', 'Americas', 2, 'Caribbean', 7, 'Puerto Rican', 18.25000000, -66.50000000, '2018-07-21 12:41:03', '2024-12-19 21:04:08', 1, 'Q1183'),
(179, 'Qatar', 'QAT', '634', 'QA', '974', 'Doha', 'QAR', 'Qatari riyal', 'ق.ر', '.qa', 'قطر', 'Asia', 3, 'Western Asia', 11, 'Qatari', 25.50000000, 51.25000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q846'),
(180, 'Reunion', 'REU', '638', 'RE', '262', 'Saint-Denis', 'EUR', 'Euro', '€', '.re', 'La Réunion', 'Africa', 1, 'Eastern Africa', 4, 'Reunionese, Reunionnais', -21.15000000, 55.50000000, '2018-07-21 12:41:03', '2024-12-19 21:04:08', 1, 'Q293585'),
(181, 'Romania', 'ROU', '642', 'RO', '40', 'Bucharest', 'RON', 'Romanian leu', 'lei', '.ro', 'România', 'Europe', 4, 'Eastern Europe', 15, 'Romanian', 46.00000000, 25.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q218'),
(182, 'Russia', 'RUS', '643', 'RU', '7', 'Moscow', 'RUB', 'Russian ruble', '₽', '.ru', 'Россия', 'Europe', 4, 'Eastern Europe', 15, 'Russian', 60.00000000, 100.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q159'),
(183, 'Rwanda', 'RWA', '646', 'RW', '250', 'Kigali', 'RWF', 'Rwandan franc', 'FRw', '.rw', 'Rwanda', 'Africa', 1, 'Eastern Africa', 4, 'Rwandan', -2.00000000, 30.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q1037'),
(184, 'Saint Helena', 'SHN', '654', 'SH', '290', 'Jamestown', 'SHP', 'Saint Helena pound', '£', '.sh', 'Saint Helena', 'Africa', 1, 'Western Africa', 3, 'Saint Helenian', -15.95000000, -5.70000000, '2018-07-21 12:41:03', '2024-12-19 21:04:08', 1, 'Q34497'),
(185, 'Saint Kitts and Nevis', 'KNA', '659', 'KN', '1', 'Basseterre', 'XCD', 'Eastern Caribbean dollar', '$', '.kn', 'Saint Kitts and Nevis', 'Americas', 2, 'Caribbean', 7, 'Kittitian or Nevisian', 17.33333333, -62.75000000, '2018-07-21 12:41:03', '2024-09-05 16:47:03', 1, 'Q763'),
(186, 'Saint Lucia', 'LCA', '662', 'LC', '1', 'Castries', 'XCD', 'Eastern Caribbean dollar', '$', '.lc', 'Saint Lucia', 'Americas', 2, 'Caribbean', 7, 'Saint Lucian', 13.88333333, -60.96666666, '2018-07-21 12:41:03', '2024-09-05 16:47:03', 1, 'Q760'),
(187, 'Saint Pierre and Miquelon', 'SPM', '666', 'PM', '508', 'Saint-Pierre', 'EUR', 'Euro', '€', '.pm', 'Saint-Pierre-et-Miquelon', 'Americas', 2, 'Northern America', 6, 'Saint-Pierrais or Miquelonnais', 46.83333333, -56.33333333, '2018-07-21 12:41:03', '2024-12-19 21:04:08', 1, 'Q34617'),
(188, 'Saint Vincent and the Grenadines', 'VCT', '670', 'VC', '1', 'Kingstown', 'XCD', 'Eastern Caribbean dollar', '$', '.vc', 'Saint Vincent and the Grenadines', 'Americas', 2, 'Caribbean', 7, 'Saint Vincentian, Vincentian', 13.25000000, -61.20000000, '2018-07-21 12:41:03', '2024-09-05 16:47:03', 1, 'Q757'),
(189, 'Saint-Barthelemy', 'BLM', '652', 'BL', '590', 'Gustavia', 'EUR', 'Euro', '€', '.bl', 'Saint-Barthélemy', 'Americas', 2, 'Caribbean', 7, 'Barthelemois', 18.50000000, -63.41666666, '2018-07-21 12:41:03', '2024-12-19 21:00:55', 1, 'Q25362'),
(190, 'Saint-Martin (French part)', 'MAF', '663', 'MF', '590', 'Marigot', 'EUR', 'Euro', '€', '.mf', 'Saint-Martin', 'Americas', 2, 'Caribbean', 7, 'Saint-Martinoise', 18.08333333, -63.95000000, '2018-07-21 12:41:03', '2025-05-05 17:57:05', 1, 'Q126125'),
(191, 'Samoa', 'WSM', '882', 'WS', '685', 'Apia', 'WST', 'Samoan tālā', 'SAT', '.ws', 'Samoa', 'Oceania', 5, 'Polynesia', 22, 'Samoan', -13.58333333, -172.33333333, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q683'),
(192, 'San Marino', 'SMR', '674', 'SM', '378', 'San Marino', 'EUR', 'Euro', '€', '.sm', 'San Marino', 'Europe', 4, 'Southern Europe', 16, 'Sammarinese', 43.76666666, 12.41666666, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q238'),
(193, 'Sao Tome and Principe', 'STP', '678', 'ST', '239', 'Sao Tome', 'STN', 'Dobra', 'Db', '.st', 'São Tomé e Príncipe', 'Africa', 1, 'Middle Africa', 2, 'Sao Tomean', 1.00000000, 7.00000000, '2018-07-21 12:41:03', '2025-03-22 20:09:58', 1, 'Q1039'),
(194, 'Saudi Arabia', 'SAU', '682', 'SA', '966', 'Riyadh', 'SAR', 'Saudi riyal', '﷼', '.sa', 'المملكة العربية السعودية', 'Asia', 3, 'Western Asia', 11, 'Saudi, Saudi Arabian', 25.00000000, 45.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q851'),
(195, 'Senegal', 'SEN', '686', 'SN', '221', 'Dakar', 'XOF', 'West African CFA franc', 'CFA', '.sn', 'Sénégal', 'Africa', 1, 'Western Africa', 3, 'Senegalese', 14.00000000, -14.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q1041'),
(196, 'Serbia', 'SRB', '688', 'RS', '381', 'Belgrade', 'RSD', 'Serbian dinar', 'din', '.rs', 'Србија', 'Europe', 4, 'Southern Europe', 16, 'Serbian', 44.00000000, 21.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q403'),
(197, 'Seychelles', 'SYC', '690', 'SC', '248', 'Victoria', 'SCR', 'Seychellois rupee', 'SRe', '.sc', 'Seychelles', 'Africa', 1, 'Eastern Africa', 4, 'Seychellois', -4.58333333, 55.66666666, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q1042'),
(198, 'Sierra Leone', 'SLE', '694', 'SL', '232', 'Freetown', 'SLL', 'Sierra Leonean leone', 'Le', '.sl', 'Sierra Leone', 'Africa', 1, 'Western Africa', 3, 'Sierra Leonean', 8.50000000, -11.50000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q1044'),
(199, 'Singapore', 'SGP', '702', 'SG', '65', 'Singapur', 'SGD', 'Singapore dollar', '$', '.sg', 'Singapore', 'Asia', 3, 'South-Eastern Asia', 13, 'Singaporean', 1.36666666, 103.80000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q334'),
(200, 'Slovakia', 'SVK', '703', 'SK', '421', 'Bratislava', 'EUR', 'Euro', '€', '.sk', 'Slovensko', 'Europe', 4, 'Eastern Europe', 15, 'Slovak', 48.66666666, 19.50000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q214'),
(201, 'Slovenia', 'SVN', '705', 'SI', '386', 'Ljubljana', 'EUR', 'Euro', '€', '.si', 'Slovenija', 'Europe', 4, 'Southern Europe', 16, 'Slovenian, Slovene', 46.11666666, 14.81666666, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q215'),
(202, 'Solomon Islands', 'SLB', '090', 'SB', '677', 'Honiara', 'SBD', 'Solomon Islands dollar', 'Si$', '.sb', 'Solomon Islands', 'Oceania', 5, 'Melanesia', 20, 'Solomon Island', -8.00000000, 159.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q685'),
(203, 'Somalia', 'SOM', '706', 'SO', '252', 'Mogadishu', 'SOS', 'Somali shilling', 'Sh.so.', '.so', 'Soomaaliya', 'Africa', 1, 'Eastern Africa', 4, 'Somali, Somalian', 10.00000000, 49.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q1045'),
(204, 'South Africa', 'ZAF', '710', 'ZA', '27', 'Pretoria', 'ZAR', 'South African rand', 'R', '.za', 'South Africa', 'Africa', 1, 'Southern Africa', 5, 'South African', -29.00000000, 24.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q258'),
(205, 'South Georgia', 'SGS', '239', 'GS', '500', 'Grytviken', 'GBP', 'British pound', '£', '.gs', 'South Georgia', 'Americas', 2, 'South America', 8, 'South Georgia or South Sandwich Islands', -54.50000000, -37.00000000, '2018-07-21 12:41:03', '2024-12-19 21:04:08', 1, 'Q1137202');
INSERT INTO `countries` (`id`, `name`, `iso3`, `numeric_code`, `iso2`, `phonecode`, `capital`, `currency`, `currency_name`, `currency_symbol`, `tld`, `native`, `region`, `region_id`, `subregion`, `subregion_id`, `nationality`, `latitude`, `longitude`, `created_at`, `updated_at`, `flag`, `wikiDataId`) VALUES
(206, 'South Sudan', 'SSD', '728', 'SS', '211', 'Juba', 'SSP', 'South Sudanese pound', '£', '.ss', 'South Sudan', 'Africa', 1, 'Middle Africa', 2, 'South Sudanese', 7.00000000, 30.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q958'),
(207, 'Spain', 'ESP', '724', 'ES', '34', 'Madrid', 'EUR', 'Euro', '€', '.es', 'España', 'Europe', 4, 'Southern Europe', 16, 'Spanish', 40.00000000, -4.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q29'),
(208, 'Sri Lanka', 'LKA', '144', 'LK', '94', 'Colombo', 'LKR', 'Sri Lankan rupee', 'Rs', '.lk', 'śrī laṃkāva', 'Asia', 3, 'Southern Asia', 14, 'Sri Lankan', 7.00000000, 81.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q854'),
(209, 'Sudan', 'SDN', '729', 'SD', '249', 'Khartoum', 'SDG', 'Sudanese pound', '.س.ج', '.sd', 'السودان', 'Africa', 1, 'Northern Africa', 1, 'Sudanese', 15.00000000, 30.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q1049'),
(210, 'Suriname', 'SUR', '740', 'SR', '597', 'Paramaribo', 'SRD', 'Surinamese dollar', '$', '.sr', 'Suriname', 'Americas', 2, 'South America', 8, 'Surinamese', 4.00000000, -56.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q730'),
(211, 'Svalbard and Jan Mayen Islands', 'SJM', '744', 'SJ', '47', 'Longyearbyen', 'NOK', 'Norwegian krone', 'ko', '.sj', 'Svalbard og Jan Mayen', 'Europe', 4, 'Northern Europe', 18, 'Svalbard', 78.00000000, 20.00000000, '2018-07-21 12:41:03', '2024-12-23 15:33:12', 1, 'Q842829'),
(212, 'Eswatini', 'SWZ', '748', 'SZ', '268', 'Mbabane', 'SZL', 'Lilangeni', 'E', '.sz', 'Swaziland', 'Africa', 1, 'Southern Africa', 5, 'Swazi', -26.50000000, 31.50000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q1050'),
(213, 'Sweden', 'SWE', '752', 'SE', '46', 'Stockholm', 'SEK', 'Swedish krona', 'ko', '.se', 'Sverige', 'Europe', 4, 'Northern Europe', 18, 'Swedish', 62.00000000, 15.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q34'),
(214, 'Switzerland', 'CHE', '756', 'CH', '41', 'Bern', 'CHF', 'Swiss franc', 'CHf', '.ch', 'Schweiz', 'Europe', 4, 'Western Europe', 17, 'Swiss', 47.00000000, 8.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q39'),
(215, 'Syria', 'SYR', '760', 'SY', '963', 'Damascus', 'SYP', 'Syrian pound', 'LS', '.sy', 'سوريا', 'Asia', 3, 'Western Asia', 11, 'Syrian', 35.00000000, 38.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q858'),
(216, 'Taiwan', 'TWN', '158', 'TW', '886', 'Taipei', 'TWD', 'New Taiwan dollar', '$', '.tw', '臺灣', 'Asia', 3, 'Eastern Asia', 12, 'Chinese, Taiwanese', 23.50000000, 121.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q865'),
(217, 'Tajikistan', 'TJK', '762', 'TJ', '992', 'Dushanbe', 'TJS', 'Tajikistani somoni', 'SM', '.tj', 'Тоҷикистон', 'Asia', 3, 'Central Asia', 10, 'Tajikistani', 39.00000000, 71.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q863'),
(218, 'Tanzania', 'TZA', '834', 'TZ', '255', 'Dodoma', 'TZS', 'Tanzanian shilling', 'TSh', '.tz', 'Tanzania', 'Africa', 1, 'Eastern Africa', 4, 'Tanzanian', -6.00000000, 35.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q924'),
(219, 'Thailand', 'THA', '764', 'TH', '66', 'Bangkok', 'THB', 'Thai baht', '฿', '.th', 'ประเทศไทย', 'Asia', 3, 'South-Eastern Asia', 13, 'Thai', 15.00000000, 100.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q869'),
(220, 'Togo', 'TGO', '768', 'TG', '228', 'Lome', 'XOF', 'West African CFA franc', 'CFA', '.tg', 'Togo', 'Africa', 1, 'Western Africa', 3, 'Togolese', 8.00000000, 1.16666666, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q945'),
(221, 'Tokelau', 'TKL', '772', 'TK', '690', '', 'NZD', 'New Zealand dollar', '$', '.tk', 'Tokelau', 'Oceania', 5, 'Polynesia', 22, 'Tokelauan', -9.00000000, -172.00000000, '2018-07-21 12:41:03', '2024-12-19 21:04:08', 1, 'Q36823'),
(222, 'Tonga', 'TON', '776', 'TO', '676', 'Nuku\'alofa', 'TOP', 'Tongan paʻanga', '$', '.to', 'Tonga', 'Oceania', 5, 'Polynesia', 22, 'Tongan', -20.00000000, -175.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q678'),
(223, 'Trinidad and Tobago', 'TTO', '780', 'TT', '1', 'Port of Spain', 'TTD', 'Trinidad and Tobago dollar', '$', '.tt', 'Trinidad and Tobago', 'Americas', 2, 'Caribbean', 7, 'Trinidadian or Tobagonian', 11.00000000, -61.00000000, '2018-07-21 12:41:03', '2024-09-05 16:47:03', 1, 'Q754'),
(224, 'Tunisia', 'TUN', '788', 'TN', '216', 'Tunis', 'TND', 'Tunisian dinar', 'ت.د', '.tn', 'تونس', 'Africa', 1, 'Northern Africa', 1, 'Tunisian', 34.00000000, 9.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q948'),
(225, 'Turkey', 'TUR', '792', 'TR', '90', 'Ankara', 'TRY', 'Turkish lira', '₺', '.tr', 'Türkiye', 'Asia', 3, 'Western Asia', 11, 'Turkish', 39.00000000, 35.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q43'),
(226, 'Turkmenistan', 'TKM', '795', 'TM', '993', 'Ashgabat', 'TMT', 'Turkmenistan manat', 'T', '.tm', 'Türkmenistan', 'Asia', 3, 'Central Asia', 10, 'Turkmen', 40.00000000, 60.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q874'),
(227, 'Turks and Caicos Islands', 'TCA', '796', 'TC', '1', 'Cockburn Town', 'USD', 'United States dollar', '$', '.tc', 'Turks and Caicos Islands', 'Americas', 2, 'Caribbean', 7, 'Turks and Caicos Island', 21.75000000, -71.58333333, '2018-07-21 12:41:03', '2024-12-19 21:04:08', 1, 'Q18221'),
(228, 'Tuvalu', 'TUV', '798', 'TV', '688', 'Funafuti', 'AUD', 'Australian dollar', '$', '.tv', 'Tuvalu', 'Oceania', 5, 'Polynesia', 22, 'Tuvaluan', -8.00000000, 178.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q672'),
(229, 'Uganda', 'UGA', '800', 'UG', '256', 'Kampala', 'UGX', 'Ugandan shilling', 'USh', '.ug', 'Uganda', 'Africa', 1, 'Eastern Africa', 4, 'Ugandan', 1.00000000, 32.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q1036'),
(230, 'Ukraine', 'UKR', '804', 'UA', '380', 'Kyiv', 'UAH', 'Ukrainian hryvnia', '₴', '.ua', 'Україна', 'Europe', 4, 'Eastern Europe', 15, 'Ukrainian', 49.00000000, 32.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q212'),
(231, 'United Arab Emirates', 'ARE', '784', 'AE', '971', 'Abu Dhabi', 'AED', 'United Arab Emirates dirham', 'إ.د', '.ae', 'دولة الإمارات العربية المتحدة', 'Asia', 3, 'Western Asia', 11, 'Emirati, Emirian, Emiri', 24.00000000, 54.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q878'),
(232, 'United Kingdom', 'GBR', '826', 'GB', '44', 'London', 'GBP', 'British pound', '£', '.uk', 'United Kingdom', 'Europe', 4, 'Northern Europe', 18, 'British, UK', 54.00000000, -2.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q145'),
(233, 'United States', 'USA', '840', 'US', '1', 'Washington', 'USD', 'United States dollar', '$', '.us', 'United States', 'Americas', 2, 'Northern America', 6, 'American', 38.00000000, -97.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q30'),
(234, 'United States Minor Outlying Islands', 'UMI', '581', 'UM', '1', '', 'USD', 'United States dollar', '$', '.us', 'United States Minor Outlying Islands', 'Americas', 2, 'Northern America', 6, 'American', 0.00000000, 0.00000000, '2018-07-21 12:41:03', '2024-12-19 21:04:08', 1, 'Q16645'),
(235, 'Uruguay', 'URY', '858', 'UY', '598', 'Montevideo', 'UYU', 'Uruguayan peso', '$', '.uy', 'Uruguay', 'Americas', 2, 'South America', 8, 'Uruguayan', -33.00000000, -56.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q77'),
(236, 'Uzbekistan', 'UZB', '860', 'UZ', '998', 'Tashkent', 'UZS', 'Uzbekistani soʻm', 'лв', '.uz', 'O‘zbekiston', 'Asia', 3, 'Central Asia', 10, 'Uzbekistani, Uzbek', 41.00000000, 64.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q265'),
(237, 'Vanuatu', 'VUT', '548', 'VU', '678', 'Port Vila', 'VUV', 'Vanuatu vatu', 'VT', '.vu', 'Vanuatu', 'Oceania', 5, 'Melanesia', 20, 'Ni-Vanuatu, Vanuatuan', -16.00000000, 167.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q686'),
(238, 'Vatican City State (Holy See)', 'VAT', '336', 'VA', '379', 'Vatican City', 'EUR', 'Euro', '€', '.va', 'Vaticano', 'Europe', 4, 'Southern Europe', 16, 'Vatican', 41.90000000, 12.45000000, '2018-07-21 12:41:03', '2023-08-11 21:15:55', 1, 'Q237'),
(239, 'Venezuela', 'VEN', '862', 'VE', '58', 'Caracas', 'VES', 'Bolívar', 'Bs', '.ve', 'Venezuela', 'Americas', 2, 'South America', 8, 'Venezuelan', 8.00000000, -66.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q717'),
(240, 'Vietnam', 'VNM', '704', 'VN', '84', 'Hanoi', 'VND', 'Vietnamese đồng', '₫', '.vn', 'Việt Nam', 'Asia', 3, 'South-Eastern Asia', 13, 'Vietnamese', 16.16666666, 107.83333333, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q881'),
(241, 'Virgin Islands (British)', 'VGB', '092', 'VG', '1', 'Road Town', 'USD', 'United States dollar', '$', '.vg', 'British Virgin Islands', 'Americas', 2, 'Caribbean', 7, 'British Virgin Island', 18.43138300, -64.62305000, '2018-07-21 12:41:03', '2024-12-19 21:04:08', 1, 'Q25305'),
(242, 'Virgin Islands (US)', 'VIR', '850', 'VI', '1', 'Charlotte Amalie', 'USD', 'United States dollar', '$', '.vi', 'United States Virgin Islands', 'Americas', 2, 'Caribbean', 7, 'U.S. Virgin Island', 18.34000000, -64.93000000, '2018-07-21 12:41:03', '2024-12-19 21:04:08', 1, 'Q11703'),
(243, 'Wallis and Futuna Islands', 'WLF', '876', 'WF', '681', 'Mata Utu', 'XPF', 'CFP franc', '₣', '.wf', 'Wallis et Futuna', 'Oceania', 5, 'Polynesia', 22, 'Wallis and Futuna, Wallisian or Futunan', -13.30000000, -176.20000000, '2018-07-21 12:41:03', '2024-12-19 21:04:08', 1, 'Q35555'),
(244, 'Western Sahara', 'ESH', '732', 'EH', '212', 'El-Aaiun', 'MAD', 'Moroccan dirham', 'MAD', '.eh', 'الصحراء الغربية', 'Africa', 1, 'Northern Africa', 1, 'Sahrawi, Sahrawian, Sahraouian', 24.50000000, -13.00000000, '2018-07-21 12:41:03', '2024-12-23 15:33:12', 1, 'Q6250'),
(245, 'Yemen', 'YEM', '887', 'YE', '967', 'Sanaa', 'YER', 'Yemeni rial', '﷼', '.ye', 'اليَمَن', 'Asia', 3, 'Western Asia', 11, 'Yemeni', 15.00000000, 48.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q805'),
(246, 'Zambia', 'ZMB', '894', 'ZM', '260', 'Lusaka', 'ZMW', 'Zambian kwacha', 'ZK', '.zm', 'Zambia', 'Africa', 1, 'Southern Africa', 5, 'Zambian', -15.00000000, 30.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q953'),
(247, 'Zimbabwe', 'ZWE', '716', 'ZW', '263', 'Harare', 'ZWL', 'Zimbabwe Dollar', '$', '.zw', 'Zimbabwe', 'Africa', 1, 'Eastern Africa', 4, 'Zimbabwean', -20.00000000, 30.00000000, '2018-07-21 12:41:03', '2023-08-10 00:53:19', 1, 'Q954'),
(248, 'Kosovo', 'XKX', '926', 'XK', '383', 'Pristina', 'EUR', 'Euro', '€', '.xk', 'Republika e Kosovës', 'Europe', 4, 'Eastern Europe', 15, 'Kosovar, Kosovan', 42.56129090, 20.34030350, '2020-08-16 08:03:50', '2023-08-11 21:16:28', 1, 'Q1246'),
(249, 'Curaçao', 'CUW', '531', 'CW', '599', 'Willemstad', 'ANG', 'Netherlands Antillean guilder', 'ƒ', '.cw', 'Curaçao', 'Americas', 2, 'Caribbean', 7, 'Curacaoan', 12.11666700, -68.93333300, '2020-10-26 07:24:20', '2023-08-11 21:15:55', 1, 'Q25279'),
(250, 'Sint Maarten (Dutch part)', 'SXM', '534', 'SX', '1721', 'Philipsburg', 'ANG', 'Netherlands Antillean guilder', 'ƒ', '.sx', 'Sint Maarten', 'Americas', 2, 'Caribbean', 7, 'Sint Maarten', 18.03333300, -63.05000000, '2020-12-06 05:33:39', '2023-08-10 00:53:19', 1, 'Q26273');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `country_continent` (`region_id`),
  ADD KEY `country_subregion` (`subregion_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=251;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `countries`
--
ALTER TABLE `countries`
  ADD CONSTRAINT `country_continent_final` FOREIGN KEY (`region_id`) REFERENCES `regions` (`id`),
  ADD CONSTRAINT `country_subregion_final` FOREIGN KEY (`subregion_id`) REFERENCES `subregions` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
