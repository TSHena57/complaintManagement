<div class="btn-group">
    <?php if($row->assessment_evaluations()->where('is_draft', 1)->where('created_by', auth()->id())->count() > 0): ?>
        <a href="<?php echo e(route('peer_assesment_pending.entry_details_edit_view',$row->id)); ?>" class="btn btn-sm btn-secondary">Pending</a>
    <?php elseif($row->assessment_evaluations()->where('is_draft', 0)->where('created_by', auth()->id())->count() > 0): ?>
        <button type="button" class="btn btn-sm btn-success">Submitted</button>
    <?php else: ?>
        <a href="<?php echo e(route('peer_assesment_pending.entry_details_store_view',$row->id)); ?>" class="btn btn-sm btn-outline-primary">Apply</a>
    <?php endif; ?>
    
</div><?php /**PATH C:\xampp\htdocs\dscsc\Modules/MututalAssesment\resources/views/peer_assesment_pending/components/action.blade.php ENDPATH**/ ?>