<?php $__env->startSection('title'); ?>
    User Information
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
    <div class="breadcrumb-title pe-3">User Management/System Setting</div>
    <div class="ps-3">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0 p-0">
                <li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt"></i></a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">Edit User Information</li>
            </ol>
        </nav>
    </div>
</div>
<!--end breadcrumb-->
<div class="row">
	<div class="col-xl-12 mx-auto">
		<div class="card">
			<div class="card-body">
				<div class="border p-3 rounded">
					<form class="row g-4" method="POST" action="<?php echo e(route('user.update', $user->id)); ?>" enctype="multipart/form-data">
						<?php echo csrf_field(); ?>
						<div class="col-xl-4">
							<label class="form-label" for="name">Name <span class="text-danger">*</span></label>
							<input type="text" class="form-control" id="name" name="name" placeholder="Name" value="<?php echo e($user->name); ?>" required>
						</div>
						<div class="col-xl-4">
							<label class="form-label" for="mobile">Mobile <span class="text-danger">*</span></label>
							<input type="text" class="form-control" id="mobile" name="mobile" placeholder="Mobile" value="<?php echo e($user->mobile); ?>" required>
						</div>
						<div class="col-xl-4">
							<label class="form-label" for="email">Email <span class="text-danger">*</span></label>
							<input type="text" class="form-control" id="email" name="email" placeholder="Email" value="<?php echo e($user->email); ?>" required>
						</div>
						<div class="col-xl-4">
							<label class="form-label" for="nid">NID </label>
							<input type="text" class="form-control" id="nid" name="nid" placeholder="NID" value="<?php echo e($user->nid); ?>">
						</div>
						<div class="col-xl-4">
							<label class="form-label" for="passport">Passport </label>
							<input type="text" class="form-control" id="passport" name="passport" placeholder="Passport" value="<?php echo e($user->passport); ?>">
						</div>
						<div class="col-xl-4">
							<label class="form-label" for="address">Address </label>
							<input type="text" class="form-control" id="address" name="address" placeholder="Address" value="<?php echo e($user->address); ?>">
						</div>
						<div class="col-xl-4">
							<label class="form-label">Gender </label>
							<select class="form-select single-select" id="gender" name="gender">
								<option value="0">-- Select --</option>
								<option value="Male" <?php if($user->gender == "Male"): echo 'selected'; endif; ?>>Male</option>
								<option value="Female" <?php if($user->gender == "Female"): echo 'selected'; endif; ?>>Female</option>
								<option value="Others" <?php if($user->gender == "Others"): echo 'selected'; endif; ?>>Others</option>
							</select>
						</div>
						<div class="col-xl-4">
							<label class="form-label">Blood Group </label>
							<select class="form-select single-select" id="blood_group" name="blood_group">
								<option value="0">-- Select --</option>
								<option value="A+" <?php if($user->blood_group == "A+"): echo 'selected'; endif; ?>>A+</option>
								<option value="A-" <?php if($user->blood_group == "A-"): echo 'selected'; endif; ?>>A-</option>
								<option value="B+" <?php if($user->blood_group == "B+"): echo 'selected'; endif; ?>>B+</option>
								<option value="B-" <?php if($user->blood_group == "B-"): echo 'selected'; endif; ?>>B-</option>
								<option value="AB+" <?php if($user->blood_group == "AB+"): echo 'selected'; endif; ?>>AB+</option>
								<option value="AB-" <?php if($user->blood_group == "AB-"): echo 'selected'; endif; ?>>AB-</option>
								<option value="O+" <?php if($user->blood_group == "O+"): echo 'selected'; endif; ?>>O+</option>
								<option value="O-" <?php if($user->blood_group == "O-"): echo 'selected'; endif; ?>>O-</option>
							</select>
						</div>
						<div class="col-xl-4">
							<label class="form-label">Religion </label>
							<select class="form-select single-select" id="religion" name="religion">
								<option value="0">-- Select --</option>
								<option value="Islam" <?php if($user->religion == "Islam"): echo 'selected'; endif; ?>>Islam</option>
                                <option value="Hinduism" <?php if($user->religion == "Hinduism"): echo 'selected'; endif; ?>>Hinduism</option>
                                <option value="Christianity" <?php if($user->religion == "Christianity"): echo 'selected'; endif; ?>>Christianity</option>
                                <option value="Buddhism" <?php if($user->religion == "Buddhism"): echo 'selected'; endif; ?>>Buddhism</option>
                                <option value="Judaism" <?php if($user->religion == "Judaism"): echo 'selected'; endif; ?>>Judaism</option>
                                <option value="Sikhism" <?php if($user->religion == "Sikhism"): echo 'selected'; endif; ?>>Sikhism</option>
                                <option value="Others" <?php if($user->religion == "Others"): echo 'selected'; endif; ?>>Others</option>

							</select>
						</div>
						<div class="col-xl-4">
							<label class="form-label" for="country_id">Country </label>
							<select class="form-select server-select country_id" id="country_id" name="country_id">
								<option value="<?php echo e($user->country_id); ?>"><?php echo e($user->country->name); ?></option>											
							</select>
						</div>
						<div class="col-xl-4">
							<label class="form-label" for="city_id">City </label>
							<select class="form-select server-select city_id" id="city_id" name="city_id">
								<option value="<?php echo e($user->city_id); ?>"><?php echo e($user->city->name); ?></option>				
							</select>
						</div>
						<div class="col-xl-4">
							<label class="form-label">Service </label>
							<select class="form-select single-select" id="service" name="service">
								<option value="Army" <?php if($user->service == "Army"): echo 'selected'; endif; ?>>Army</option>
								<option value="Navy" <?php if($user->service == "Navy"): echo 'selected'; endif; ?>>Navy</option>
								<option value="Air" <?php if($user->service == "Air"): echo 'selected'; endif; ?>>Air</option>
							</select>
						</div>
						<div class="col-xl-4">
							<label class="form-label">Rank </label>
							<select class="form-select single-select" id="rank_id" name="rank_id">
								<?php $__currentLoopData = $ranks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($rank->id); ?>" <?php if($user->rank_id == $rank->id): echo 'selected'; endif; ?>><?php echo e($rank->name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>
						<div class="col-xl-4">
							<label class="form-label">Appointment Classification </label>
							<select class="form-select single-select" id="appointment_classification_id" name="appointment_classification_id">
								<?php $__currentLoopData = $appontments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appontment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($appontment->id); ?>" <?php if($user->appointment_classification_id == $appontment->id): echo 'selected'; endif; ?>><?php echo e($appontment->name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>
						<div class="col-xl-4">
							<label class="form-label">Date of Commission </label>
							<input type="date" class="form-control" placeholder="Date of Commission" id="date_of_commission" name="date_of_commission" value="<?php echo e($user->date_of_commission); ?>">
						</div>
						<div class="col-xl-4">
							<label class="form-label">Date of Join in DSCSC </label>
							<input type="date" class="form-control" placeholder="Date of Join in DSCSC" id="date_of_join_in_dscsc" name="date_of_join_in_dscsc" value="<?php echo e($user->date_of_join_in_dscsc); ?>">
						</div>
						<div class="col-xl-4">
							<label class="form-label">Photo </label>
							<input class="form-control" type="file" id="formFile" name="photo">
						</div>
						<div class="col-xl-4">
							<label class="form-label">Password </label>
							<input type="password" class="form-control" id="signature" name="password">
						</div>
						<div class="col-xl-4">
							<label class="form-label">Signature </label>
							<input class="form-control" type="file" id="signature" name="signature">
						</div>
						<div class="col-xl-4">
							<label class="form-label">User Type </label>
							<select class="form-select single-select" id="user_type" name="user_type">
								<option value="0">-- Select Type --</option>
								<option value="Parmanent" <?php if($user->user_type == "Parmanent"): echo 'selected'; endif; ?>>Parmanent</option>
								<option value="Non-Parmanent" <?php if($user->user_type == "Non-Parmanent"): echo 'selected'; endif; ?>>Non-Parmanent</option>
							</select>
						</div>
						<div class="col-xl-4">
							<label class="form-label">Role Assign </label>
							<select class="form-select single-select" id="role_id" name="role_id">
								<option value="0">-- Select --</option>
								<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($role->id); ?>" <?php if($user->role_id == $role->id): echo 'selected'; endif; ?>><?php echo e($role->name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>

						<div class="submit text-end">
							<button type="Submit" class="btn btn-primary px-5">Submit</button>
						</div>
					</form>

				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        $(function () { 
            "use strict";
            $(".country_id").select2({
                ajax: {
                    url: '<?php echo e(route('country.list_for_select_ajax')); ?>',
                    type: "get",
                    dataType: 'json',
                    delay: 250,
                    data: function (params) {
                            var query = {
                                search: params.term,
                                page: params.page || 1,
                            }
                            return query;
                    },
                    cache: false
                },
                escapeMarkup: function (m) {
                    return m;
                }
            });
            $(".city_id").select2({
                ajax: {
                    url: '<?php echo e(route('cities.list_for_select_ajax')); ?>',
                    type: "get",
                    dataType: 'json',
                    delay: 250,
                    data: function (params) {
                            var query = {
                                search: params.term,
                                page: params.page || 1,
                                country_id: $('#country_id').val(),
                            }
                            return query;
                    },
                    cache: false
                },
                escapeMarkup: function (m) {
                    return m;
                }
            });
                
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin_app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dscsc\resources\views/user/edit.blade.php ENDPATH**/ ?>