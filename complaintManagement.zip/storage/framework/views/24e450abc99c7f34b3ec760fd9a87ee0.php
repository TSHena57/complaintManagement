<div class="btn-group">
    <a href="<?php echo e(route('peer_assesment_setup.show',$row->id)); ?>" class="btn btn-sm btn-outline-info"><i class="bi bi-eye-fill"></i></a>
    <a href="<?php echo e(route('peer_assesment_setup.edit',$row->id)); ?>" class="btn btn-sm btn-outline-warning"><i class="bi bi-pencil-fill"></i></a>
    <button type="button" class="btn btn-sm btn-outline-danger delete_item" onclick="deleteData('Assessment Setup', '<?php echo e(route('peer_assesment_setup.delete')); ?>', <?php echo e($row->id); ?>)"><i class="bi bi-trash-fill"></i></button>
</div><?php /**PATH C:\xampp\htdocs\dscsc\Modules/MututalAssesment\resources/views/peer_assesment_setup/components/action.blade.php ENDPATH**/ ?>