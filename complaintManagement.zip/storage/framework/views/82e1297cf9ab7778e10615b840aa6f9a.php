<?php $__env->startSection('title'); ?>
    Permission
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
    <div class="breadcrumb-title pe-3">User Management/System Setting</div>
    <div class="ps-3">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0 p-0">
                <li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt"></i></a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">Permission List</li>
            </ol>
        </nav>
    </div>
</div>
<div class="col-xl-12">
    <div class="card">
        <div class="card-body p-4">
            <h5 class="mb-3">Permission List For : <?php echo e($role->name); ?></h5>
            <form class="form-action" action="<?php echo e(route('user-management.permission-store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" value="<?php echo e(request()->route()->parameter('id')); ?>" name="role_id" />
                <div class="row">
                    <div class="col-md-12 mb-2 fw-bold">
                        <div id="" class="form-check">
                            <input class="form-check-input checkAll" type="checkbox" value="" id="checkAll">
                            <label class="form-check-label" for="checkAll">
                                Select All
                            </label>
                        </div>
                    </div>
                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 mb-3">
                        <div class="accordion" id="accordionPanel">
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="<?php echo e($key); ?>">
                                    <button class="accordion-button bg-secondary-subtle fw-bold text-primary" type="button" data-bs-toggle="collapse" data-bs-target="#<?php echo e($key); ?>-collapseOne" aria-expanded="true" aria-controls="<?php echo e($key); ?>-collapseOne">
                                        <?php echo e(ucwords(str_replace('-',' ',$key))); ?>

                                    </button>
                                </h2>
                                <div id="<?php echo e($key); ?>-collapseOne" class="accordion-collapse collapse" aria-labelledby="<?php echo e($key); ?>">
                                    <div class="accordion-body">
                                        <fieldset class="the-fieldset">
                                            <legend class="the-legend"><?php echo e(ucwords(str_replace('-',' ',$key))); ?></legend>
                                                <?php $__currentLoopData = $permission->groupBy('sub_module'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_module => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="row mb-3">
                                                        <div class="col-md-12 mb-2 fw-bold">
                                                            <div class="form-check">
                                                                <input class="form-check-input checkAllSubModuleAction" type="checkbox" value="checkAll<?php echo e($sub_module); ?>" id="checkAll<?php echo e($sub_module); ?>">
                                                                <label class="form-check-label fw-semibold" for="checkAll<?php echo e($sub_module); ?>">
                                                                        <?php echo e(ucwords(str_replace('-',' ',$sub_module))); ?>

                                                                </label>
                                                            </div>
                                                        </div>
                                                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="form-check col-md-4 px-5">
                                                                <input class="form-check-input selctOption_1 checkAll<?php echo e($sub_module); ?>" type="checkbox" name="permissions[]" value="<?php echo e($item->name); ?>" <?php echo e(in_array($item->id, $existing_permissions) ? 'checked' : ''); ?>>
                                                                <label class="form-check-label">
                                                                    <?php echo e(ucwords(str_replace('-',' ',$item->name))); ?>

                                                                </label>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </fieldset>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <br> <br>
                    <div class="col-md-12"><button type="submit" class="btn btn-primary">Update</button></div>
                </div>
            </form>
        </div>
    </div>
</div>


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(".checkAll").change(function() {
        $(".selctOption_1").prop("checked", $(this).prop("checked"));
    });
    $(document).on('change','.checkAllSubModuleAction', function(){
        $('.'+$(this).val()).prop("checked", $(this).prop("checked"));
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dscsc\resources\views/permission/permission_index.blade.php ENDPATH**/ ?>