<?php $__env->startSection('content'); ?>
<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
    <div class="breadcrumb-title pe-3">Dashboard</div>
    <div class="ps-3">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0 p-0">
                <li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt"></i></a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
            </ol>
        </nav>
    </div>
</div>
<div class="row row-cols-1 row-cols-lg-2 row-cols-xl-2 row-cols-xxl-4">
   <div class="col">
      <div class="card radius-10">
         <div class="card-body">
            <div class="d-flex align-items-center">
               <div class="m-3 fs-2 text-primary">
                  <i class="bi bi-person"></i>
               </div>
               <div class="col-3">
                  <p class="mb-1">Local-CP</p>
                  <h4 class="mb-0 text-primary"><?php echo e(number_format($local_cp)); ?></h4>
               </div>
               <div class="m-3 fs-2 text-primary ">
                  <i class="bi bi-person"></i>
               </div>
               <div class="col-4">
                  <p class="mb-1">Foreign-CP</p>
                  <h4 class="mb-0 text-primary"><?php echo e(number_format($foreign_cp)); ?></h4>
               </div>
            </div>
         </div>
      </div>
   </div>
   <div class="col">
      <div class="card radius-10">
         <div class="card-body">
            <div class="d-flex align-items-center">
               <div class="m-3 fs-2 text-success">
                  <i class="bi bi-people-fill "></i>
               </div>
               <div class="col-3">
                  <p class="mb-1">Group </p>
                  <h4 class="mb-0 text-success"><?php echo e(number_format($total_group)); ?> </h4>
               </div>
               <div class="m-3 fs-2 text-success">
                  <i class="bi bi-calendar2-event "></i>
               </div>
               <div class="col-4">
                  <p class="mb-1">Event</p>
                  <h4 class="mb-0 text-success"><?php echo e(number_format($total_event)); ?> </i></h4>
               </div>
            </div>
         </div>
      </div>
   </div>
   <div class="col">
      <div class="card radius-10">
         <div class="card-body ">
            <div class="d-flex align-items-center">
               <div class="m-3 fs-2 text-pink">
                  <i class="bi bi-folder2-open"></i>
               </div>
               <div class="">
                  <p class="mb-1">Pending Assessment</p>
                  <h4 class="mb-0 text-pink">10</h4>
               </div>
            </div>
         </div>
      </div>
   </div>
   <div class="col">
      <div class="card radius-10">
         <div class="card-body">
            <div class="d-flex align-items-center">
               <div class="text-success m-3 fs-2">
                  <i class="bi bi-file-earmark-break  text-orange"></i>
               </div>
               <div class="">
                  <p class="mb-1">Submitied Assessment</p>
                  <h4 class="mb-0 text-orange">146</h4>
               </div>
               <div class="ms-auto fs-2 text-orange">
                  <i class="bi folder-minus"></i>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<!--end row-->
<div class="row">
   <div class="col-12 col-lg-8 col-xl-8">
      <div class="card radius-10">
         <div class="card-body">
            <div class="row row-cols-1 row-cols-lg-2 g-3 align-items-center mb-3">
               <div class="col">
                  <h5 class="mb-0">Student Assessment</h5>
               </div>
            </div>
            <div id="chart1"></div>
         </div>
      </div>
   </div>
   <div class="col-12 col-lg-4 col-xl-4">
      <div class="card">
         <div class="col-xl-12 p-4">
            <label class="form-label">Participant Name<span class="text-danger">*</label>
            <select class="multiple-select" data-placeholder="Choose anything" multiple="multiple">
               <option value="50001" selected>Maj Rahim (50001)</option>
               <option value="50002" selected>Maj Karim (50002)</option>
               <option value="50003">Wg Cdr Salina Gomez (50003)</option>
               <option value="50004">Lt Cdr Raton Lal (50004)</option>
            </select>
         </div>
         <div class="card-body">
            <div id="chart2"></div>
         </div>
      </div>
   </div>
   <div class="col-12">
      <div class="card p-4">
         <div class="chart-container1">
            <canvas id="chart3"></canvas>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>

  <script src="<?php echo e(asset('assets/plugins/apexcharts-bundle/js/apexcharts.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/index2.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/plugins/chartjs/js/Chart.min.js')); ?>"></script>
    <script>
      var optionsLine = {
         chart: {
            foreColor: '#9ba7b2',
            height: 360,
            type: 'line',
            zoom: {
               enabled: false
            },
            dropShadow: {
               enabled: true,
               top: 3,
               left: 2,
               blur: 4,
               opacity: 0.1,
            }
         },
         stroke: {
            curve: 'smooth',
            width: 5
         },
         colors: ["#e72e2e", '#0c971a'],
         series: [{
            name: "CP-4001",
            data: [28, 20, 55, 70]
         }, {
            name: "CP-4002",
            data: [15, 35, 40, 80]
         }],
         title: {
            text: 'Term wise Comparison',
            align: 'left',
            offsetY: 25,
            offsetX: 20
         },
         subtitle: {
            text: 'Statistics',
            offsetY: 55,
            offsetX: 20
         },
         markers: {
            size: 4,
            strokeWidth: 0,
            hover: {
               size: 7
            }
         },
         grid: {
            show: true,
            padding: {
               bottom: 0
            }
         },
         //labels: ['01/15/2002', '01/16/2002', '01/17/2002', '01/18/2002', '01/19/2002', '01/20/2002'],
         xaxis: {
            //type: 'datetime',
            categories: ['Term-1', 'Term-2', 'Term-3', 'Term-4'],
         },
         legend: {
            position: 'top',
            horizontalAlign: 'right',
            offsetY: -20
         }
      }
      var chartLine = new ApexCharts(document.querySelector('#chart2'), optionsLine);
      chartLine.render();

      new Chart(document.getElementById("chart3"), {
         type: 'pie',
         data: {
            labels: ["CP-50001", "Cp-50002", "Cp-50003", "Cp-50004",],
            datasets: [{
                  label: "Population (millions)",
                  backgroundColor: ["#0d6efd", "#212529", "#17a00e", "#f41127",],
                  data: [50, 40, 30, 85,]
            }]
         },
         options: {
            maintainAspectRatio: false,
            title: {
                  display: true,
                  text: 'Student Assessment'
            }
         }
      });
   </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin_app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dscsc\Modules/MututalAssesment\resources/views/dashboard_admin.blade.php ENDPATH**/ ?>