<aside class="sidebar-wrapper" data-simplebar="true">
   <div class="sidebar-header">
      <div>
         <img src="<?php echo e(asset('assets/images/logo.jpg')); ?>" class="logo-icon" alt="logo icon">
      </div>
      <div>
         <h4 class="logo-text">PMP</h4>
      </div>
      <div class="toggle-icon ms-auto"><i class="bi bi-chevron-double-left"></i>
      </div>
   </div>
   <!--navigation-->
   <ul class="metismenu" id="menu">
      <li>
         <a href="javascript:;" class="has-arrow">
            <div class="parent-icon"><i class="bi bi-grid"></i>
            </div>
            <div class="menu-title"> User Management/System Setting</div>
         </a>
         <ul>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['User-list'])): ?>
            <li>
               <a href="<?php echo e(route('user.index')); ?>"><i class="bi bi-arrow-right-short"></i>User Information</a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['role-list','role-permission'])): ?>
            <li class="<?php if(Route::is('user-management.*')): ?> mm-active <?php endif; ?>">
               <a href="<?php echo e(route('user-management.role-index')); ?>"><i class="bi bi-arrow-right-short"></i>Role Permission Assign</a>
            </li>
            <?php endif; ?>
            <li>
               <a href="#"><i class="bi bi-arrow-right-short"></i>Alert Log/Massage</a>
            </li>
            </li>
            <li>
               <a href="<?php echo e(route('change_password')); ?>"><i class="bi bi-arrow-right-short"></i>Change Password</a>
            </li>
         </ul>
      </li>
      
   </ul>
   <!--end navigation-->
</aside><?php /**PATH C:\xampp\htdocs\pmp\resources\views/layouts/partials/admin_sidebar.blade.php ENDPATH**/ ?>