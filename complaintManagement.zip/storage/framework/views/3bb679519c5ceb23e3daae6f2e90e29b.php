
<?php $__env->startSection('title'); ?>
    Change Password
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="authentication-card">
    <div class="card shadow rounded-0 overflow-hidden">
        <div class="row g-0">
            <div class="col-lg-6 d-flex align-items-center justify-content-center border-end">
                <img src="<?php echo e(asset('assets/images/logo.png')); ?>" class="img-fluid" alt="">
            </div>
            <div class="col-lg-6">
                <div class="card-body p-4 p-sm-5">
                    <h5 class="card-title">Genrate New Password</h5>
                    <form class="form-body" method="POST" action="<?php echo e(route('update_change_password')); ?>">
						<?php echo csrf_field(); ?>
                        <div class="row g-3 my-4">
                            <div class="col-12">
                                <label for="new_password" class="form-label">New Password</label>
                                <div class="ms-auto position-relative">
                                    <div class="position-absolute top-50 translate-middle-y search-icon px-3"><i class="bi bi-lock-fill"></i></div>
                                    <input type="password" class="form-control radius-30 ps-5" id="new_password" name="new_password" placeholder="Enter New Password">
                                </div>
                            </div>
                            <div class="col-12">
                                <label for="new_password_confirmation" class="form-label">Confirm Password</label>
                                <div class="ms-auto position-relative">
                                    <div class="position-absolute top-50 translate-middle-y search-icon px-3"><i class="bi bi-lock-fill"></i></div>
                                    <input type="password" class="form-control radius-30 ps-5" id="new_password_confirmation" name="new_password_confirmation" placeholder="Confirm Password">
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="d-grid gap-3">
                                    <button type="submit" class="btn btn-primary radius-30">Change Password</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pmp\resources\views/user/change_password.blade.php ENDPATH**/ ?>