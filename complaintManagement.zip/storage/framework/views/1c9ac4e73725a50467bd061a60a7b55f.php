<div class="btn-group">
    <button type="button" class="btn btn-sm btn-outline-warning edit_item" data-route="<?php echo e(route('academic_years.edit',$row->id)); ?>"><i class="bi bi-pencil-fill"></i></button>
    <button type="button" class="btn btn-sm btn-outline-danger delete_item" onclick="deleteData('Academic Year', '<?php echo e(route('academic_years.delete')); ?>', <?php echo e($row->id); ?>)"><i class="bi bi-trash-fill"></i></button>
</div><?php /**PATH C:\xampp\htdocs\dscsc\Modules/MututalAssesment\resources/views/academic_years/components/action.blade.php ENDPATH**/ ?>