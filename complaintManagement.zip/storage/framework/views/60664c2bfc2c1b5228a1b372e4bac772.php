<div class="btn-group">
    <a href="<?php echo e(route('academic_syndicate_groups.edit',$row->id)); ?>" class="btn btn-sm btn-outline-warning"><i class="bi bi-pencil-fill"></i></a>
    <button type="button" class="btn btn-sm btn-outline-danger delete_item" onclick="deleteData('Syndicate Group', '<?php echo e(route('academic_syndicate_groups.delete')); ?>', <?php echo e($row->id); ?>)"><i class="bi bi-trash-fill"></i></button>
</div><?php /**PATH C:\xampp\htdocs\dscsc\Modules/MututalAssesment\resources/views/academic_syndicate_groups/components/action.blade.php ENDPATH**/ ?>