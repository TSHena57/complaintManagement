
<li>
    <a href="<?php echo e(route('home')); ?>">
        <div class="parent-icon"><i class="bi bi-house-door"></i>
        </div>
        <div class="menu-title">Dashboard</div>
    </a>
</li>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['academic-year-list', 'academic-course-list', 'academic-term-list','division-list','syndicate-list','evaluation-domain-list','city-list','rank-list','appointment-list'])): ?>
<li>
   <a href="javascript:;" class="has-arrow">
      <div class="parent-icon"><i class="bi bi-grid"></i>
      </div>
      <div class="menu-title">General Setup</div>
   </a>
   <ul>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['academic-year-list'])): ?>
        <li>
            <a href="<?php echo e(route('academic_years.index')); ?>"><i class="bi bi-arrow-right-short"></i> Academic Year </a>
        </li>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['academic-course-list'])): ?>
        <li>
            <a href="<?php echo e(route('academic_courses.index')); ?>"><i class="bi bi-arrow-right-short"></i> Academic Course </a>
        </li>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['academic-term-list'])): ?>
        <li>
            <a href="<?php echo e(route('academic_terms.index')); ?>"><i class="bi bi-arrow-right-short"></i> Academic Term </a>
        </li>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['division-list'])): ?>
        <li>
            <a href="<?php echo e(route('academic_divisions.index')); ?>"><i class="bi bi-arrow-right-short"></i> Academic Division </a>
        </li>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['syndicate-list'])): ?>
        <li class="<?php if(Route::is('academic_syndicate_groups.*')): ?> mm-active <?php endif; ?>">
            <a href="<?php echo e(route('academic_syndicate_groups.index')); ?>"><i class="bi bi-arrow-right-short"></i> Syndicates / Group </a>
        </li>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['evaluation-domain-list'])): ?>
        <li>
            <a href="<?php echo e(route('evaluation_domain.index')); ?>"><i class="bi bi-arrow-right-short"></i> Evaluation Domain </a>
        </li>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['city-list'])): ?>
        <li>
            <a href="<?php echo e(route('cities.index')); ?>"><i class="bi bi-arrow-right-short"></i> City </a>
        </li>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['rank-list'])): ?>
        <li>
            <a href="<?php echo e(route('ranks.index')); ?>"><i class="bi bi-arrow-right-short"></i> Rank </a>
        </li>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['appointment-list'])): ?>
        <li>
            <a href="<?php echo e(route('appointment_classifications.index')); ?>"><i class="bi bi-arrow-right-short"></i> Appointment Classification </a>
        </li>
    <?php endif; ?>
   </ul>
</li>
<?php endif; ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['event-list','assesment-setup-list','assesment-evaluation-pending-list','assesment-evaluation-submitted-list'])): ?>
<li>
   <a href="javascript:;" class="has-arrow">
      <div class="parent-icon"><i class="bi bi-grid"></i>
      </div>
      <div class="menu-title"> Peer Assessment Module</div>
   </a>
   <ul>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['event-list'])): ?>
      <li class="<?php if(Route::is('academic_events.*')): ?> mm-active <?php endif; ?>">
        <a href="<?php echo e(route('academic_events.index')); ?>"><i class="bi bi-arrow-right-short"></i>Events Setup</a>
      </li>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['assesment-setup-list'])): ?>
      <li class="<?php if(Route::is('peer_assesment_setup.*')): ?> mm-active <?php endif; ?>">
        <a href="<?php echo e(route('peer_assesment_setup.index')); ?>"><i class="bi bi-arrow-right-short"></i>Peer Assessment Setup</a>
      </li>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['assesment-evaluation-pending-list'])): ?>
      <li class="<?php if(Route::is('peer_assesment_pending.*') && !Route::is('peer_assesment_pending.submitted_index')): ?> mm-active <?php endif; ?>">
        <a href="<?php echo e(route('peer_assesment_pending.index')); ?>"><i class="bi bi-arrow-right-short"></i> Peer Assessment Pedning List </a>
      </li>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['assesment-evaluation-submitted-list'])): ?>
      <li>
        <a href="<?php echo e(route('peer_assesment_pending.submitted_index')); ?>"><i class="bi bi-arrow-right-short"></i> Peer Assessment Submit List </a>
      </li>
    <?php endif; ?>
   </ul>
</li>
<?php endif; ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['advance-assesment-report'])): ?>
<li>
    <a href="javascript:;" class="has-arrow">
        <div class="parent-icon"><i class="bi bi-grid"></i>
        </div>
        <div class="menu-title"> Analytics & Reporting </div>
    </a>
    <ul>
        <li>
            <a href="<?php echo e(route('reports.advanced_report')); ?>">
                <i class="bi bi-arrow-right-short"></i>
                <span class="menu-title">Advanced Report</span>
            </a>
        </li>
    </ul>
</li>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\dscsc\Modules/MututalAssesment\resources/views/menu.blade.php ENDPATH**/ ?>