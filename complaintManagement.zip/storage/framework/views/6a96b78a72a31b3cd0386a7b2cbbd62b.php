<div class="btn-group">
    <button type="button" class="btn btn-sm btn-outline-warning edit_item" data-route="<?php echo e(route('academic_courses.edit',$row->id)); ?>"><i class="bi bi-pencil-fill"></i></button>
    <button type="button" class="btn btn-sm btn-outline-danger delete_item" onclick="deleteData('Course', '<?php echo e(route('academic_courses.delete')); ?>', <?php echo e($row->id); ?>)"><i class="bi bi-trash-fill"></i></button>
</div><?php /**PATH C:\xampp\htdocs\dscsc\Modules/MututalAssesment\resources/views/academic_courses/components/action.blade.php ENDPATH**/ ?>