
<?php $__env->startSection('title'); ?>
    Academic Course
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
    <div class="breadcrumb-title pe-3">General Setup</div>
    <div class="ps-3">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0 p-0">
                <li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt"></i></a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">Academic Course</li>
            </ol>
        </nav>
    </div>
</div>
<div class="row">
    <div class="col-md-12">        
        <div class="card">
            <div class="card-body">
                <div class="border p-3 rounded">
                    <form class="row g-4" method="POST" action="<?php echo e(route('academic_courses.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="col-xl-6">
                            <label class="form-label" for="academic_year_id">Academic Year <span class="text-danger">*</label>
                            <select class="form-select single-select" id="academic_year_id" name="academic_year_id">
                                <option value="0">-- Select Year --</option>
                                <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($year->id); ?>"><?php echo e($year->year); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-xl-6">
                            <div class="mb-3">
                                <label class="form-label" for="course">Course <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Course Name" id="course" name="course">
                            </div>
                        </div>
                        <div class="col-12 submit text-end">
                            <button type="submit" class="btn btn-primary px-5">Submit</button>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table id="data-table" class="table table-striped table-bordered" style="width:100%">
                        <thead>
                            <tr>
                                <th width="5%">#</th>
                                <th width="20%">Academic Year</th>
                                <th>Course Name</th>
                                <th width="10%" class="text-end">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="ajaxDiv"></div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        $(function () { 
            "use strict";
            var table = $('#data-table').DataTable({
                processing: true,
                serverSide: true,
                ajax: "<?php echo e(route('academic_courses.index')); ?>",
                columns: [
                    {data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false},
                    {data: 'academic_year.year', name: 'academic_year.year'},
                    {data: 'course', name: 'course'},
                    {data: 'action', name: 'action', className: 'text-end', orderable: false, searchable: false},
                ]
            });
            $.fn.dataTable.ext.errMode = () => alert('Error while loading the table data. Please refresh');
                
        });
        $(document).on('click','.edit_item', function(){
            let url = $(this).data("route");

            $.get(url, function(data){
                $('#ajaxDiv').html(data);
                $('#editModal').modal('show');
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin_app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dscsc\Modules/MututalAssesment\resources/views/academic_courses/index.blade.php ENDPATH**/ ?>