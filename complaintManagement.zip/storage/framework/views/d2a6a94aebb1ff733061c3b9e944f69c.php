<div class="btn-group">
    <a type="button" class="btn btn-sm btn-outline-warning" href="<?php echo e(route('user.edit',$row->id)); ?>"><i class="bi bi-pencil-fill"></i></a>
    <button type="button" class="btn btn-sm btn-outline-danger delete_item" onclick="deleteData('User', '<?php echo e(route('user.delete')); ?>', <?php echo e($row->id); ?>)"><i class="bi bi-trash-fill"></i></button>
</div><?php /**PATH C:\xampp\htdocs\dscsc\resources\views/user/components/action.blade.php ENDPATH**/ ?>