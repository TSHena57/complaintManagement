<?php $__env->startSection('title'); ?>
    Evaluation Domain
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
    <div class="breadcrumb-title pe-3">General Setup</div>
    <div class="ps-3">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0 p-0">
                <li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt"></i></a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">Evaluation Domain</li>
            </ol>
        </nav>
    </div>
</div>
<div class="row">
    <div class="col-md-12">        
        <div class="card">
            <div class="card-body">
                <div class="border p-3 rounded">
                    <form class="row g-4" method="POST" action="<?php echo e(route('evaluation_domain.store')); ?>">
                        <?php echo csrf_field(); ?>
                     
                        <div class="col-xl-12">
                            <label class="form-label" for="name">Domain Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Domain Name" id="name" name="name">
                        </div>
                        <div class="col-12 submit text-end">
                            <button type="submit" class="btn btn-primary px-5">Submit</button>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table id="data-table" class="table table-striped table-bordered" style="width:100%">
                        <thead>
                            <tr>
                                <th width="5%">#</th>
                                <th>Domain Name	</th>
                                <th>Status</th>
                                <th width="10%" class="text-end">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="ajaxDiv"></div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        $(function () { 
            "use strict";
            var table = $('#data-table').DataTable({
                processing: true,
                serverSide: true,
                ajax: "<?php echo e(route('evaluation_domain.index')); ?>",
                columns: [
                    {data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false},
                    {data: 'name', name: 'name'},
                    {data: 'status', name: 'status', orderable: false, searchable: false},
                    {data: 'action', name: 'action', className: 'text-end', orderable: false, searchable: false},
                ]
            });
            $.fn.dataTable.ext.errMode = () => alert('Error while loading the table data. Please refresh');
                
        });
        $(document).on('click','.edit_item', function(){
            let url = $(this).data("route");

            $.get(url, function(data){
                $('#ajaxDiv').html(data);
                $('#editModal').modal('show');
            });
        });

        $(document).on('change', '.toggle-status', function () {
            let id = $(this).data('id');

            $.ajax({
                url: '<?php echo e(route("evaluation_domain.toggleStatus")); ?>',
                type: 'POST',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    id: id
                },
                success: function (response) {
                    if (response.success) {
                        toastr.success("Status updated to: " + (response.status ? "Active" : "Inactive"));
                    }
                },
                error: function (xhr) {
                    toastr.error(xhr.responseText);
                    // alert("Something went wrong!");
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin_app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dscsc\Modules/MututalAssesment\resources/views/evaluation_domain/index.blade.php ENDPATH**/ ?>