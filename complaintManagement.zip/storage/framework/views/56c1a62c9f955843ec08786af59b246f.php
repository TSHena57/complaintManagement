<?php $__env->startSection('title'); ?>
    Login
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   <form class="space-y-5" method="POST" action="<?php echo e(route('login')); ?>">
   <?php echo csrf_field(); ?>
   <div class="row g-3">
      <h2 align="center" class="card-title" style="font-size:18px;">PMP ERP</h2>

      <div class="col-12" style="text-align:left;">
         <label for="inputEmailAddress" class="form-label">Email Address *</label>
         <div class="ms-auto position-relative">
            <div class="position-absolute top-50 translate-middle-y search-icon px-3">
               <i class="fa-solid fa-user"></i>
            </div>
            <input type="email" class="form-control radius-30 ps-5 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
               id="inputEmailAddress" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
         </div>
      </div>

      <div class="col-12" style="text-align:left;">
         <label for="inputChoosePassword" class="form-label">Enter Password *</label>
         <div class="ms-auto position-relative">
            <div class="position-absolute top-50 translate-middle-y search-icon px-3">
               <i class="fa-solid fa-lock"></i>
            </div>

            <!-- Password Input -->
            <input type="password" 
               class="form-control radius-30 ps-5 pe-5 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
               id="inputChoosePassword" name="password" required autocomplete="current-password">

            <!-- Show/Hide Icon -->
            <div class="position-absolute top-50 end-0 translate-middle-y pe-3" style="cursor:pointer;">
               <i class="fa-solid fa-eye" id="togglePassword"></i>
            </div>
         </div>
      </div>

      <div class="col-6 d-none">
         <div class="form-check form-switch">
            <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
            <label class="form-check-label" for="remember">Remember Me</label>
         </div>
      </div>

      <div class="col-12 text-end">
         <a href="<?php echo e(route('password.request')); ?>" style="color:blue;">Forgot Password ?</a>
      </div>

      <div class="col-12">
         <div class="d-grid">
            <button type="submit" class="btn btn-primary radius-30">Sign In</button>
         </div>
      </div>
   </div>
</form>

<script>
   const togglePassword = document.querySelector('#togglePassword');
   const passwordInput = document.querySelector('#inputChoosePassword');

   togglePassword.addEventListener('click', function () {
      const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
      passwordInput.setAttribute('type', type);
      this.classList.toggle('fa-eye');
      this.classList.toggle('fa-eye-slash');
   });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth_app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\complaintManagement\complaintLaravel\resources\views/auth/login.blade.php ENDPATH**/ ?>