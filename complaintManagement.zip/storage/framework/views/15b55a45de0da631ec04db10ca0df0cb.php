
<?php $__env->startSection('title'); ?>
    Academic Term
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
    <div class="breadcrumb-title pe-3">General Setup</div>
    <div class="ps-3">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0 p-0">
                <li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt"></i></a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">Academic Term</li>
            </ol>
        </nav>
    </div>
</div>
<div class="row">
    <div class="col-md-12">        
        <div class="card">
            <div class="card-body">
                <div class="border p-3 rounded">
                    <form class="row g-4" method="POST" action="<?php echo e(route('academic_terms.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="col-xl-4">
                            <label class="form-label" for="academic_year_id">Academic Year <span class="text-danger">*</label>
                            <select class="form-select single-select" id="academic_year_id" name="academic_year_id">
                                <option value="0">-- Select Year --</option>
                                <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($year->id); ?>"><?php echo e($year->year); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-xl-4">
                            <label class="form-label" for="academic_course_id">Course Name <span class="text-danger">*</label>
                            <select class="form-select server-select academic_course_id" id="academic_course_id" name="academic_course_id">
                                <option value="0">-- Select Course --</option>
                            </select>
                        </div>
                        <div class="col-xl-4">
                            <div class="mb-3">
                                <label class="form-label" for="terms">Terms <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Terms Name" id="terms" name="terms">
                            </div>
                        </div>
                        <div class="col-12 submit text-end">
                            <button type="submit" class="btn btn-primary px-5">Submit</button>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table id="data-table" class="table table-striped table-bordered" style="width:100%">
                        <thead>
                            <tr>
                                <th width="5%">#</th>
                                <th>Academic Year</th>
                                <th>Course Name</th>
                                <th>Terms</th>
                                <th width="10%" class="text-end">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="ajaxDiv"></div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        $(function () { 
            "use strict";
            var table = $('#data-table').DataTable({
                processing: true,
                serverSide: true,
                ajax: "<?php echo e(route('academic_terms.index')); ?>",
                columns: [
                    {data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false},
                    {data: 'academic_year.year', name: 'academic_year.year'},
                    {data: 'academic_course.course', name: 'academic_course.course'},
                    {data: 'terms', name: 'terms'},
                    {data: 'action', name: 'action', className: 'text-end', orderable: false, searchable: false},
                ]
            });
            $.fn.dataTable.ext.errMode = () => alert('Error while loading the table data. Please refresh');
                
        });
        $(".academic_course_id").select2({
            ajax: {
                url: '<?php echo e(route('academic_courses.list_for_select_ajax')); ?>',
                type: "get",
                dataType: 'json',
                delay: 250,
                data: function (params) {
                        var query = {
                            search: params.term,
                            page: params.page || 1,
                            academic_year: $('#academic_year_id').val(),
                        }
                        return query;
                },
                cache: false
            },
            escapeMarkup: function (m) {
                return m;
            }
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin_app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dscsc\Modules/MututalAssesment\resources/views/academic_terms/index.blade.php ENDPATH**/ ?>