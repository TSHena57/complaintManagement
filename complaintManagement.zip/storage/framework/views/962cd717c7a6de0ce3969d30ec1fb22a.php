<?php $__env->startSection('title'); ?>
    Login
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row g-0">
   <div class="col-lg-6 bg-login d-flex align-items-center justify-content-center">
      <img src="<?php echo e(asset('assets/images/logo.png')); ?>" class="img-fluid" alt="<?php echo e(env('APP_NAME')); ?>">
   </div>
   <div class="col-lg-6">
      <div class="card-body p-4 p-sm-5">
         <form class="form-body" action="<?php echo e(route('login')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="login-separater text-center mb-4">
               <span>SIGN IN WITH EMAIL</span>
               <hr>
            </div>
            <div class="row g-3">
               <div class="col-12">
                  <label for="email" class="form-label">Email</label>
                  <div class="ms-auto position-relative">
                     <div class="position-absolute top-50 translate-middle-y search-icon px-3"><i class="bi bi-envelope-fill"></i></div>
                     <input type="email" class="form-control radius-30 ps-5" id="email" <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> placeholder="Email" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                  
                     <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                           <strong><?php echo e($message); ?></strong>
                        </span>
                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
               </div>
               <div class="col-12">
                  <label for="password" class="form-label">Enter Password</label>
                  <div class="ms-auto position-relative">
                     <div class="position-absolute top-50 translate-middle-y search-icon px-3 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><i class="bi bi-lock-fill" id="togglePassword"></i></div>
                     <input type="password" class="form-control radius-30 ps-5" id="password" placeholder="Enter Password" name="password" required autocomplete="current-password">
                  </div>
               </div>
               <div class="col-6">
                  <div class="form-check form-switch">
                     <input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked" checked="">
                     <label class="form-check-label" for="flexSwitchCheckChecked">Remember Me</label>
                  </div>
               </div>
               <div class="col-6 text-end">	<a href="<?php echo e(route('password.request')); ?>">Forgot Password ?</a>
               </div>
               <div class="col-12">
                  <div class="d-grid">
                     <button type="submit" class="btn btn-primary radius-30">Sign In</button>
                  </div>
               </div>
            </div>
         </form>
      </div>
   </div>
</div>

<script>
   const togglePassword = document.querySelector('#togglePassword');
   const passwordInput = document.querySelector('#password');

   togglePassword.addEventListener('click', function () {
      const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
      passwordInput.setAttribute('type', type);
      this.classList.toggle('fa-eye');
      this.classList.toggle('fa-eye-slash');
   });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth_app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\complaintManagement\resources\views/auth/login.blade.php ENDPATH**/ ?>