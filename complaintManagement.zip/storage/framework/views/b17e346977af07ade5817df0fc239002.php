<?php $__env->startSection('content'); ?>
<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
    <div class="ps-3">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0 p-0">
                <li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt"></i></a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
            </ol>
        </nav>
    </div>
</div>
<div class="row">
   <div class="col-xl-12 mx-auto">
      <div class="card">
         <div class="card-body">
            <div class="border p-3 rounded">
               <form class="row g-4">
                  <div class="row g-2  ">
                     <div class="col-xl-2 g-3">
                        <div class="info">
                           <h6 class="mb-2">Name</h6>
                           <p class="mb-1">Appointment</p>
                           <p class="mb-1">Rank</p>
                           <p class="mb-1">BA no</p>
                           <p class="mb-1">Address</p>
                        </div>
                     </div>
                     <div class="col-xl-8 g-3">
                        <div class="info">
                           <h6 class="mb-2"><?php echo e($user->name); ?></h6>
                           <p class="mb-1"><?php echo e($user->role->name); ?></p>
                           <p class="mb-1"><?php echo e($user->rank->name); ?></p>
                           <p class="mb-1"><?php echo e($user->id); ?></p>
                           <p class="mb-1"><?php echo e($user->address); ?></p>
                        </div>
                     </div>
                     <div class="col-xl-2 " style="max-width: 160px;">
                        <img src="<?php echo e(asset('assets/images/avatars/avatar-1.png')); ?>" class="rounded img-fluid img-thumbnail honour-board-flip-card-img mb-10" alt="air.jpg">
                     </div>
                  </div>
               </form>
            </div>
         </div>
      </div>
      <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
         <div class="ps-3">
            <nav aria-label="breadcrumb">
               <ol class="breadcrumb mb-0 p-0">
                  <li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt"></i></a>
                  </li>
                  <li class="breadcrumb-item active" aria-current="page">Pending Assessment List</li>
               </ol>
            </nav>
         </div>
      </div>
      <div class="row">
         <div class="col-md-12">
            <div class="card">
               <div class="card-body">
                  <div class="table-responsive">
                     <table id="data-table" class="table table-striped table-bordered" style="width:100%">
                        <thead>
                           <tr>
                              <th width="5%">#</th>
                              <th>Assessment No/Name</th>
                              <th>Event </th>
                              <th>Deadline </th>
                              <th>Domian Weightage</th>
                              <th width="10%" class="text-end">Action</th>
                           </tr>
                        </thead>
                        <tbody>
                        </tbody>
                     </table>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
         <div class="ps-3">
            <nav aria-label="breadcrumb">
               <ol class="breadcrumb mb-0 p-0">
                  <li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt"></i></a>
                  </li>
                  <li class="breadcrumb-item active" aria-current="page">Events List</li>
               </ol>
            </nav>
         </div>
      </div>
      <div class="row">
         <div class="col-md-12">
            <div class="card">
               <div class="card-body">
                  <div class="table-responsive">
                     <table id="data-table-2" class="table table-striped table-bordered" style="width:100%">
                        <thead>
                           <tr>
                              <th width="5%">#</th>
                                <th>Event</th>
                                <th>Location</th>
                                <th>Description</th>
                                <th>Start Date</th>
                                <th>End Date</th>
                              <th width="4%" class="text-end">Action</th>
                           </tr>
                        </thead>
                        <tbody>
                        </tbody>
                     </table>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    $(function () { 
        "use strict";
        var table = $('#data-table').DataTable({
            processing: true,
            serverSide: true,
            ajax: "<?php echo e(route('peer_assesment_pending.index')); ?>",
            columns: [
                {data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false},
                {data: 'assesment_name', name: 'assesment_name'},
                {data: 'academic_event.event_name', name: 'academic_event.event_name'},
                {data: 'last_date', name: 'last_date'},
                {data: 'weightage', name: 'weightage'},
                {data: 'action', name: 'action', className: 'text-end', orderable: false, searchable: false},
            ]
        });
        $.fn.dataTable.ext.errMode = () => alert('Error while loading the table data. Please refresh');
          
        var table = $('#data-table-2').DataTable({
            processing: true,
            serverSide: true,
            ajax: "<?php echo e(route('academic_events.self_event_index')); ?>",
            columns: [
                {data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false},
                {data: 'event_name', name: 'event_name'},
                {data: 'event_location', name: 'event_location'},
                {data: 'event_description', name: 'event_description'},
                {data: 'start_date', name: 'start_date'},
                {data: 'end_date', name: 'end_date'},
                {data: 'action', name: 'action', className: 'text-end', orderable: false, searchable: false},
            ]
        });
        $.fn.dataTable.ext.errMode = () => alert('Error while loading the table data. Please refresh');
            
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin_app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dscsc\Modules/MututalAssesment\resources/views/dashboard_cp.blade.php ENDPATH**/ ?>