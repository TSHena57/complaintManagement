<!DOCTYPE html>
<html>
<body>
    <h2>Welcome, {{ $user->name }}!</h2>
    <p>Please verify your email by clicking the button below:</p>

    <a href="{{ $url }}" 
       style="background:#4F46E5; padding:10px 20px; color:white; text-decoration:none;">
        Verify Email
    </a>

    <p>If you didn’t create an account, ignore this email.</p>
</body>
</html>
